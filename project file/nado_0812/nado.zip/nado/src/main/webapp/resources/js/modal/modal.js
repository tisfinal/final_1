'use strict';

//클래스=. id=#


$('.checkIn').click(function(){
    $('.modalShow1').addClass('modal-open');
});

$('.close').click(function(){
    $('.modalShow1').removeClass('modal-open');
});
///////////////////////////////////////////////
$('.checkOut').click(function(){
    $('.modalShow2').addClass('modal-open');
});

$('.close').click(function(){
    $('.modalShow2').removeClass('modal-open');
});
