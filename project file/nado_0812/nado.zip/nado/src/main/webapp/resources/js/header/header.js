'use strict';


let menu2=$('span.menu1');
let leftBox=$('.leftBox');


let key=1;

menu2.on('click',()=>{
   let _this=$(this);
   
    if(key==1){
    leftBox.animate({left:'0'},500);
        key=0;
    }else{
       leftBox.animate({left:'-100%'},500);
        key=1;
    } 
});

//////////////////////////////////////////////////////////////////////////


const topHeader=document.querySelector('.topHeader');
// const innerHeader=document.querySelector('.inner-header');
//const Top=document.querySelector('.Top');
// const gnb=document.querySelector('.gnb');


document.addEventListener('scroll',()=>{
    let sTop=document.documentElement.scrollTop;

    if(sTop>=100){
        topHeader.classList.add('scrollOn');
        topHeader.style.background='#fff';
    }else{
        topHeader.classList.remove('scrollOn');
        topHeader.style.background='#fff0';
    
    }   

});


