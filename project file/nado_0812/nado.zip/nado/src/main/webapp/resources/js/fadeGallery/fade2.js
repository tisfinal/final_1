'use strict';

//--------스크립트로 이미지 넣는다.----------------------
let galleryLi=document.querySelectorAll('.gallery>ul>li');
let arrBg=[];
for(let i=0;i<galleryLi.length;i++){
                //경로: img폴더 -> hotel 폴더 -> hotel0.png ~ oo.png 
    arrBg.push('url(img/room/room'+i+'.png) no-repeat 50%/cover');
    galleryLi[i].style.background=arrBg[i];
}
//-----------------------------------------------------
let gallery=document.querySelector('.gallery');

let i=-1;
function Gallery(){
    if(i>=galleryLi.length-1) i=-1;  
    i++
    galleryLi.forEach(function(target, index){
        if(index===i){
            target.classList.add('fade');
            ItemsLi[index].classList.add('on');
        
        }else{
             target.classList.remove('fade');
            ItemsLi[index].classList.remove('on');
        }
     });
  
    //i5번째에서 다시 첫번째로
    if(i>=galleryLi.length-1) i=-1;
    
}

//------------------화살표 부분-------------------------------
let spanS1=document.querySelectorAll('span.s1');
spanS1[1].innerText=galleryLi.length;

let startNum=0;
let arrow=document.querySelectorAll('span.arrow');

arrow[1].addEventListener('click',function(){
    startNum++;
    if(startNum>galleryLi.length-1){
        startNum=0;
    } 
    jsFadeFunc(startNum);
    
});
arrow[0].addEventListener('click',function(){
    startNum--; //galleryLi의 index이다.
      if(startNum<0){
        startNum=galleryLi.length-1;
    } 
    jsFadeFunc(startNum);
    
});
//------------startNum 넣기-------add_fade---remove_fade-------

function jsFadeFunc(innerNum){
    console.log(innerNum);

    spanS1[0].innerText=innerNum+1;
    
    galleryLi.forEach(function(target, index){
       if(index===innerNum){
           target.classList.add('fade');
       }else{
            target.classList.remove('fade');
       }
    });


}
//---------------------------------------------------------

//윈도우가 실행되면 이 함수를 실행해라
(function(){
   jsFadeFunc(startNum);  //처음 실행되면 startNum이 0이다. 
})();














































