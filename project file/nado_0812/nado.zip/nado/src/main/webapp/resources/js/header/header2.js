'use strict';


const header=document.querySelector('.header');
const middleLogo=document.querySelector('.middle');

document.addEventListener('scroll',()=>{
    let sTop=document.documentElement.scrollTop;
    if(sTop>=100){
        header.style.backgroundColor='#fff';
        middleLogo.style.display='block';
    }else{
        header.style.backgroundColor='rgba(255, 255, 255, 0)';
        middleLogo.style.display='none';
        // header.style.display='none';
    }   

});





