package move.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractAction;

public class MypageAction extends AbstractAction {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		req.setAttribute("test", "MyPage");
		
		this.setViewPage("/member/mypage.jsp");
		this.setRedirect(false);
	}

}
