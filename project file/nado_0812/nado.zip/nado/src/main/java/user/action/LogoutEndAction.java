package user.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.controller.AbstractAction;
import common.util.CommonUtil;

public class LogoutEndAction extends AbstractAction {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		HttpSession session=req.getSession();
		session.invalidate();
		
		String str = "�α׾ƿ� �ƽ��ϴ�.";
		String loc = req.getContextPath() + "/index.nd"; // ������

		CommonUtil.addMsgLoc(req, str, loc); //setattribute 
		this.setViewPage("../msg.jsp");
		this.setRedirect(false);

	}

}
