package user.action;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.controller.AbstractAction;
import common.util.CommonUtil;
import user.model.NotUserException;
import user.model.UserDAOMyBatis;
import user.model.UserVO;

public class LoginEndAction extends AbstractAction {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
	
		String id = req.getParameter("id");
		String pwd = req.getParameter("pwd");
		
		
		UserDAOMyBatis userDao = new UserDAOMyBatis();

		try {
			UserVO loginUser = userDao.loginCheck(id, pwd);
			

			if (loginUser != null) {//�α����� �� ���

				HttpSession session = req.getSession();
				session.setAttribute("loginUser", loginUser);
				
				Cookie ck=new Cookie("uid", loginUser.getMember_id());
				if(id!=null) {

					ck.setMaxAge(7*24*60*60);
				}else {
					ck.setMaxAge(0);
				}
				ck.setPath("/");
				res.addCookie(ck);
				
				
				String str = "�α��ο� �����߽��ϴ�.";
				String loc = req.getContextPath() + "/index.nd"; // ������

				CommonUtil.addMsgLoc(req, str, loc); //setattribute 
				this.setViewPage("../msg.jsp");
				this.setRedirect(false);

			}

		} catch (NotUserException e) {//�α��� ���� ��
			String str = e.getMessage();
			String loc = req.getContextPath() + "/member/login.nd"; 
			/*
			 * req.setAttribute("message", str); 
			 * req.setAttribute("loc", loc);
			 
			 */
			CommonUtil.addMsgLoc(req, str, loc); //setattribute 
			this.setRedirect(false);
			this.setViewPage("../msg.jsp");
		}

	}

}
