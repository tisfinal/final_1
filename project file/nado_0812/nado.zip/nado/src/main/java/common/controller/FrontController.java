package common.controller;

import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class FrontController
 */
//@WebServlet(
//		urlPatterns = { "*.nd" }, 
//		initParams = { 
//				@WebInitParam(name = "config", value = "C:\\Users\\User\\eclipse-workspace\\nado\\src\\main\\webapp\\WEB-INF\\Command.properties")
//		})
//   C:\\MYjava\\Workspace\\
@WebServlet(
		urlPatterns = { "*.nd" }, 
		initParams = { 
				@WebInitParam(name = "config", value = "C:\\MYjava\\Workspace\\nado\\src\\main\\webapp\\WEB-INF\\Command.properties")
		})
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	private HashMap<String, Object> cmdMap=new HashMap<>();
	
	@Override
	public void init(ServletConfig conf) throws ServletException{
		System.out.println("init()ȣ���...");
		String props=conf.getInitParameter("config");
		System.out.println("props="+props);
		
		Properties pr=new Properties();
		try {
			FileReader fr=new FileReader(props);
			pr.load(fr);
			if(fr!=null) fr.close();
			
			Set<Object> set=pr.keySet();
			
			for(Object key:set) {
				String cmd=key.toString(); 
				String className=pr.getProperty(cmd);
				if(className!=null) {
					className=className.trim();
				}
			
				Class<?> cls=Class.forName(className);
				Object cmdInstance=cls.newInstance();
				
				cmdMap.put(cmd, cmdInstance);
				
			}// for-------------------
			
			
		}catch(Exception e) {
			e.printStackTrace();
			throw new ServletException(e);
		}
	}//init()----------------------------------------

	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}
	
	
	private void process(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
			{
				String cmd=request.getServletPath();
				System.out.println("cmd: "+cmd);
				
				Object instance=cmdMap.get(cmd);
				if(instance==null) {
					System.out.println("Action�� null");
					throw new ServletException("Action�� null�Դϴ�");
				}
				System.out.println("instance=="+instance);
				
				AbstractAction action=(AbstractAction)instance;
				
				try {
				action.execute(request, response);
				
				String viewPage=action.getViewPage();
				boolean isRedirect=action.isRedirect();
				
				if(isRedirect) {
					response.sendRedirect(viewPage);
				}else {
					System.out.println("viewPage="+viewPage);
					RequestDispatcher disp=request.getRequestDispatcher(viewPage);
					disp.forward(request, response);
					
				}
				
				}catch(Exception e) {
					e.printStackTrace();
					throw new ServletException(e);
				}
			}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

}
