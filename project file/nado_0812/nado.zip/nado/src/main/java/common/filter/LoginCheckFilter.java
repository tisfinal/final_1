package common.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import common.util.CommonUtil;
import user.model.UserVO;

/**
 * Servlet Filter implementation class LoginCheckFilter
 * /user/* ������ ��û�� ������ LoginCheckFilter�� �����Ѵ�.
 */
//@WebFilter("/user/*")
@WebFilter(urlPatterns = {"/member/mypage.nd"})
public class LoginCheckFilter implements Filter {

	public void destroy() {
		
	}

	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
	     System.out.println("LoginCheckFilter...");
		//���ǿ� ����Ǿ� �ִ� loginUser�� �ִ��� üũ�ؼ� ���ٸ� return;
		//�ִٸ� ���� ���ͷ� �ͱ��.
		HttpServletRequest req=(HttpServletRequest)request;
		
		HttpSession ses=req.getSession();
		UserVO user=(UserVO)ses.getAttribute("loginUser");
		if(user==null) {
			String str="�α����ؾ� �̿��� �� �־��";
			String loc=req.getContextPath()+"/member/login.nd";
			CommonUtil.addMsgLoc(req, str, loc);
			//forward�̵�----
			RequestDispatcher disp=req.getRequestDispatcher("/msg.jsp");
			disp.forward(req, response);
			return;
		}
		chain.doFilter(request, response);
		
	}

	
	public void init(FilterConfig fConfig) throws ServletException {
		
	}

}
