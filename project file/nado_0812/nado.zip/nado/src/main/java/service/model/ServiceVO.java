package service.model;

import java.sql.Date;

public class ServiceVO {
	
	private String user_id;
	private int room_id;
	private Date check_in;
	private Date check_out;
	private int hotel_id;
	
	
	public ServiceVO() {
		
	}


	public ServiceVO(String user_id, int room_id, Date check_in, Date check_out, int hotel_id) {
		super();
		this.user_id = user_id;
		this.room_id = room_id;
		this.check_in = check_in;
		this.check_out = check_out;
		this.hotel_id = hotel_id;
	}


	public String getUser_id() {
		return user_id;
	}


	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}


	public int getRoom_id() {
		return room_id;
	}


	public void setRoom_id(int room_id) {
		this.room_id = room_id;
	}


	public Date getCheck_in() {
		return check_in;
	}


	public void setCheck_in(Date check_in) {
		this.check_in = check_in;
	}


	public Date getCheck_out() {
		return check_out;
	}


	public void setCheck_out(Date check_out) {
		this.check_out = check_out;
	}


	public int getHotel_id() {
		return hotel_id;
	}


	public void setHotel_id(int hotel_id) {
		this.hotel_id = hotel_id;
	}
	
	
	
	
	
	
	

}
