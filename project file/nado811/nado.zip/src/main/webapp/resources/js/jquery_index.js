'use strict';

// let vh = window.innerHeight * 0.01;
// document.documentElement.style.setProperty("--vh", `${vh}px`);

let arrowTop=$('span.arrowTop');
  
$(window).on('scroll',function(){
 
    let docTop=$(document).scrollTop(); 
    console.log(docTop);
    if(docTop>=80){
        arrowTop.fadeIn();

    }else{
     
         arrowTop.fadeOut();
        arrowTop.addClass('arrowTopClass');
    }
    
    let sec1=$('.section.sec1');
    let sec2=$('.section.sec2');
    let sec3=$('.section.sec3');
    
    let sec1Top=sec1.offset().top;
    let sec2Top=sec2.offset().top;
    let sec3Top=sec3.offset().top;
  
    
    if(docTop>=sec2Top && docTop<=sec3Top){
        sec3.find('.con').stop().animate({bottom:'0',opacity:'1'},600);
    }else{
        sec3.find('.con').stop().animate({bottom:'-200px',opacity:'0'},100);
    }
});
arrowTop.on('click',function(){
   $('html').animate({scrollTop:'0'}); 
});

let itemsLi=$('.items>ul>li');

itemsLi.on('click',function(){
    let _this=$(this);
    let _this_index=$(this).index();
    _this.addClass('on').siblings().removeClass('on');
    
    let secTop=$('.section').eq(_this_index).offset().top;
    $('html').animate({scrollTop:secTop});
    
});

//제이쿼리 모바일시 메뉴부분
// let menu=$('span.menu');
// let leftMenu=$('.left-menu');
// let item=$('.item');

// let key=true;

// menu.on('click',function(){
//    let _this=$(this);
//     _this.toggleClass('menuOn');
//     if(key){
//         leftMenu.stop().animate({left:'0'},400,function(){
//            item.eq(0).fadeIn(); 
//            item.eq(1).fadeIn(700); 
//            item.eq(2).fadeIn(900); 
//            item.eq(3).fadeIn(1500); 
//            item.eq(4).fadeIn(1800); 
//         });
//         key=false;
//     }else{
//         item.eq(0).fadeOut(1000);
//         item.eq(1).fadeOut(700);
//         item.eq(2).fadeOut(400, function(){
//             leftMenu.stop().animate({left:'-100%'},800)
//         });
        
//         key=true;
//     }
// });


























