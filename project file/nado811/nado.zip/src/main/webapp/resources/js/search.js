'use strict';

//클래스=. id=#


$('.c_date').click(function(){
    $('.modalShow1').addClass('modal-open');
});

$('.close').click(function(){
    $('.modalShow1').removeClass('modal-open');
});
///////////////////////////////////////////////
$('.p_number').click(function(){
    $('.modalShow2').addClass('modal-open');
});

$('.close').click(function(){
    $('.modalShow2').removeClass('modal-open');
});
