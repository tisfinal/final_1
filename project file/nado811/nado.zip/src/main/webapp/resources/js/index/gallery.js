'use strict';

let galleryLi=$('.gallery>ul>li');

let arrBg=[];
for(let i=0;i<galleryLi.length;i++){
    arrBg.push('url(img/index/sec'+i+'.png) no-repeat 50%/cover');
    galleryLi.eq(i).css({'background':arrBg[i]});
    
}
let itemsLi=$('.items>ul>li')

itemsLi.on('click',function(){
    console.log(event.currentTarget) //자바스트립트 dom으로 접근
    console.log($(this)); //제이쿼리 객체
    console.log($(this).index()); //자신의 인덱스번호를 추출할 수 있다.
    
    let idx=$(this).index();

    
    galleryLi.eq(idx).fadeIn(1000).siblings().fadeOut(1000);
    itemsLi.eq(idx).addClass('on').siblings().removeClass('on');
    $(this).eq(idx).addClass('on').siblings().removeClass('on');
    
    //중요
     if(idx==galleryLi.length-1) idx=-1;
    i=idx;
    
   
    
});

let i=0;
function aotopadeGallery(){
    i++;
    
    galleryLi.eq(i).fadeIn(1000).siblings().fadeOut(1000);
    itemsLi.eq(i).addClass('on').siblings().removeClass('on');
    if(i>=galleryLi.length-1) i=-1;
}



(function(){
    aotopadeGallery(i--); 
})();





























