package common.dao;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;



/*  java �ּ�

 *  ���� :  �츮�� ���� dao ���� ���������� ���� close() �Լ��� ��� ... 
 *
 * update :
 *
 * �ۼ��� :  
 */
 
public class DAOMyBatis {
	
	protected SqlSession ses;
	
	public SqlSessionFactory getSessionFactory() {
		String resouce="common/config/mybatis-config.xml";
		InputStream is=null;
		try {
			is=Resources.getResourceAsStream(resouce);
		} catch (IOException e) {
			e.printStackTrace();
		}
		SqlSessionFactory factory=new SqlSessionFactoryBuilder().build(is);
		return factory;
	}//-------------------------------------------
	
	public void close() {
		if(ses!=null) ses.close();
	}

}