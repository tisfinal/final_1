package user.model;
import java.sql.*;

public class UserVO implements java.io.Serializable{

   private String user_id;
   private String nickname;
   private String name;
   private String pwd;
   private int state;
   private String favorite_loc;
   
   public UserVO() {
      
   }

   public UserVO(String user_id, String nickname, String name, String pwd, int state, String favorite_loc) {
      super();
      this.user_id = user_id;
      this.nickname = nickname;
      this.name = name;
      this.pwd = pwd;
      this.state = state;
      this.favorite_loc = favorite_loc;
   }

   public String getUser_id() {
      return user_id;
   }

   public void setUser_id(String user_id) {
      this.user_id = user_id;
   }

   public String getNickname() {
      return nickname;
   }

   public void setNickname(String nickname) {
      this.nickname = nickname;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public String getPwd() {
      return pwd;
   }

   public void setPwd(String pwd) {
      this.pwd = pwd;
   }

   public int getState() {
      return state;
   }

   public void setState(int state) {
      this.state = state;
   }

   public String getFavorite_loc() {
      return favorite_loc;
   }

   public void setFavorite_loc(String favorite_loc) {
      this.favorite_loc = favorite_loc;
   }
   
   
   
   
}//---------------------