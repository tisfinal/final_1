package user.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractAction;
import common.util.CommonUtil;
import user.model.UserDAOMyBatis;
import user.model.UserVO;

/**ȸ������ �۵��ϴ� Ŭ����*/
public class JoinEndAction extends AbstractAction {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		String name=req.getParameter("name");
		String member_id = req.getParameter("id");
		String pwd=req.getParameter("pwd");
		String nickname=req.getParameter("nickname");
		//String favorite=req.getParameter("loc");
		String favorite="������";
		
		UserVO user = new UserVO(member_id,name,nickname,pwd,0,favorite);
		
		UserDAOMyBatis dao = new UserDAOMyBatis();
		int n = dao.joinUser(user);
		
		String str = "ȸ������ ó�� �ƽ��ϴ�."+n;
		String loc = req.getContextPath() + "/member/login.nd"; // ������

		CommonUtil.addMsgLoc(req, str, loc); //setattribute 
		this.setViewPage("../msg.jsp");
		this.setRedirect(false);
		
		
	}

}
