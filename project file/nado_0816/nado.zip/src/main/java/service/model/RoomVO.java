package service.model;

public class RoomVO {
	
	private int room_id;
	private String room_name;
	private int room_price;
	private String thumb_img;
	private int hotel_id;
	
	
	public RoomVO() {
		
	}


	public RoomVO(int room_id, String room_name, int room_price, String thumb_img, int hotel_id) {
		super();
		this.room_id = room_id;
		this.room_name = room_name;
		this.room_price = room_price;
		this.thumb_img = thumb_img;
		this.hotel_id = hotel_id;
	}


	public int getRoom_id() {
		return room_id;
	}


	public void setRoom_id(int room_id) {
		this.room_id = room_id;
	}


	public String getRoom_name() {
		return room_name;
	}


	public void setRoom_name(String room_name) {
		this.room_name = room_name;
	}


	public int getRoom_price() {
		return room_price;
	}


	public void setRoom_price(int room_price) {
		this.room_price = room_price;
	}


	public String getThumb_img() {
		return thumb_img;
	}


	public void setThumb_img(String thumb_img) {
		this.thumb_img = thumb_img;
	}


	public int getHotel_id() {
		return hotel_id;
	}


	public void setHotel_id(int hotel_id) {
		this.hotel_id = hotel_id;
	}

	
	
	
	
}
