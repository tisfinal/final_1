package service.model;

public class HotelVO {
	
	private int hotel_id;
	private String business_id;
	private String hname;
	private String htitle;
	private String hotel_address;
	private String phone;
	private String sido;
	private String gungu;
	private String thumb_img;
	private String description;
	private int min_price;
	
	private int total_star;
	private int count;
	
	

	public int getTotal_star() {
		return total_star;
	}


	public void setTotal_star(int total_star) {
		this.total_star = total_star;
	}


	public int getCount() {
		return count;
	}


	public void setCount(int count) {
		this.count = count;
	}


	
	
	public HotelVO() {
		
	}


	public HotelVO(int hotel_id, String business_id, String hname, String htitle, String hotel_address, String phone,
			String sido, String gungu, String thumb_img, String description, int min_price) {
		super();
		this.hotel_id = hotel_id;
		this.business_id = business_id;
		this.hname = hname;
		this.htitle = htitle;
		this.hotel_address = hotel_address;
		this.phone = phone;
		this.sido = sido;
		this.gungu = gungu;
		this.thumb_img = thumb_img;
		this.description = description;
		this.min_price = min_price;
	}


	public int getHotel_id() {
		return hotel_id;
	}


	public void setHotel_id(int hotel_id) {
		this.hotel_id = hotel_id;
	}


	public String getBusiness_id() {
		return business_id;
	}


	public void setBusiness_id(String business_id) {
		this.business_id = business_id;
	}


	public String getHname() {
		return hname;
	}


	public void setHname(String hname) {
		this.hname = hname;
	}


	public String getHtitle() {
		return htitle;
	}


	public void setHtitle(String htitle) {
		this.htitle = htitle;
	}


	public String getHotel_address() {
		return hotel_address;
	}


	public void setHotel_address(String hotel_address) {
		this.hotel_address = hotel_address;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getSido() {
		return sido;
	}


	public void setSido(String sido) {
		this.sido = sido;
	}


	public String getGungu() {
		return gungu;
	}


	public void setGungu(String gungu) {
		this.gungu = gungu;
	}


	public String getThumb_img() {
		return thumb_img;
	}


	public void setThumb_img(String thumb_img) {
		this.thumb_img = thumb_img;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public int getMin_price() {
		return min_price;
	}


	public void setMin_price(int min_price) {
		this.min_price = min_price;
	}
	
	
	

}
