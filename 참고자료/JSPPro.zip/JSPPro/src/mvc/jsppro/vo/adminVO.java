package mvc.jsppro.vo;

import java.sql.Timestamp;

public class adminVO {
	private String id; //관리자 아이디
	private String pwd; //관리자 비밀번호
	private int bookno; //책번호
	private String bookname; //책제목
	private String bookauthor; //책저자
	private String bookkind; //책종류
	private String bookintrod; //책소개
	private int bookprice; //책가격
	private int bookcount; //책수량
	private Timestamp bookreg_date;  //등록일자
	private int buycount; // 구매수량
	private int o_state; 
	
	public int getO_state() {
		return o_state;
	}

	public void setO_state(int o_state) {
		this.o_state = o_state;
	}

	public int getBuycount() {
		return buycount;
	}

	public void setBuycount(int buycount) {
		this.buycount = buycount;
	}

	// 기본생성자
	public adminVO() {
		
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public int getBookno() {
		return bookno;
	}
	public void setBookno(int bookno) {
		this.bookno = bookno;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public String getBookauthor() {
		return bookauthor;
	}
	public void setBookauthor(String bookauthor) {
		this.bookauthor = bookauthor;
	}
	public String getBookkind() {
		return bookkind;
	}
	public void setBookkind(String bookkind) {
		this.bookkind = bookkind;
	}
	public String getBookintrod() {
		return bookintrod;
	}
	public void setBookintrod(String bookintrod) {
		this.bookintrod = bookintrod;
	}
	public int getBookprice() {
		return bookprice;
	}
	public void setBookprice(int bookprice) {
		this.bookprice = bookprice;
	}
	public int getBookcount() {
		return bookcount;
	}
	public void setBookcount(int bookcount) {
		this.bookcount = bookcount;
	}
	public Timestamp getBookreg_date() {
		return bookreg_date;
	}
	public void setBookreg_date(Timestamp bookreg_date) {
		this.bookreg_date = bookreg_date;
	}
	
	
}
