package mvc.jsppro.admincon;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.jsppro.servicecon.adminServiceImpl;

@WebServlet("*.ad")
public class admController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public admController() {
    	super();
    }
    // 1단계 : HTTP 요청받음
	protected void doGet(HttpServletRequest req, HttpServletResponse res) 
			throws ServletException, IOException {
				ActionDo(req, res);
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
				ActionDo(req, res);
	}
	// 2단계 : 요청 분석		
	public void ActionDo(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		
		// 한글 안깨지게 처리(안하면 DB에 한글이 깨져서 Insert)
		req.setCharacterEncoding("UTF-8");
		
		String viewpage = null;
		String uri = req.getRequestURI();
		String contextPath = req.getContextPath();	// 프로젝트명
		String url = uri.substring(contextPath.length());
		
		// 관리자 메인페이지
		if(url.equals("/home.ad") || url.equals("/*.ad")) {
			System.out.println("/home.ad");
			
			viewpage = "/admin/home.jsp";
		// 관리자 폼페이지
		}else if(url.equals("/adminform.ad")) {
			System.out.println("/adminform.ad");
			
			viewpage = "/admin/adminform.jsp";
		
		// 관리자 재고관리
		}else if(url.equals("/inventory.ad")) {
			System.out.println("/inventory.ad");
			
			adminServiceImpl service = new adminServiceImpl();
			service.addminList(req, res);
			
			viewpage = "/admin/inventory.jsp";
		}
		// 관리자 재고추가 폼페이지
		else if(url.equals("/adminwriteForm.ad")) {
			System.out.println("/adminwriteForm.cu");
			
			
			viewpage = "/admin/adminwriteForm.jsp";
		}
		// 관리자 재고추가 처리페이지
		else if(url.equals("/adminwritePro.ad")) {
			System.out.println("/adminwritePro.ad");
			
			adminServiceImpl service = new adminServiceImpl();
			service.adminwritePro(req, res);
			
			viewpage = "/admin/adminwritePro.jsp";
		}
		// 관리자 재고관리 상세페이지
		else if(url.equals("/admincontentForm.ad")) {
			System.out.println("/admincontentForm.ad");
			
			adminServiceImpl service = new adminServiceImpl();
			service.admincontentFrom(req, res);
			
			viewpage = "/admin/admincontentForm.jsp";
		// 관리자 재고 수정페이지
		}else if(url.equals("/adminmodifyForm.ad")) {
			System.out.println("/adminmodifyForm.ad");
			
			int bookno = Integer.parseInt(req.getParameter("bookno"));
			int pageNum = Integer.parseInt(req.getParameter("pageNum"));
			req.setAttribute("bookno", bookno);
			req.setAttribute("pageNum", pageNum);
			
			viewpage="/admin/adminmodifyForm.jsp";
		
		// 관리자 재고 수정상세페이지
		}
		else if (url.equals("/adminmodifyView.ad")) {
			System.out.println("/adminmodifyView.ad");
			
			adminServiceImpl service = new adminServiceImpl();
			service.adminmodifyView(req, res);
			
			viewpage = "/admin/adminmodifyView.jsp";
		}
		
		
		// 관리자 재고관리 수정처리
		else if(url.equals("/adminmodifyPro.ad")) {
			System.out.println("/adminmodifyPro.ad");
			
			adminServiceImpl service = new adminServiceImpl();
			service.adminmodifyPro(req, res);
			
			viewpage = "/admin/adminmodifyPro.jsp";
			
		//관리자 재고삭제
		}else if(url.equals("/admindeleteForm.ad")) {
			System.out.println("/admindeleteForm.ad");
			
			int bookno = Integer.parseInt(req.getParameter("bookno"));
			int pageNum = Integer.parseInt(req.getParameter("pageNum"));
			
			req.setAttribute("bookno", bookno);
			req.setAttribute("pageNum", pageNum);
			
			viewpage = "/admin/admindeleteForm.jsp";
		// 관리자 재고삭제 처리	
		}else if(url.equals("/admindeletePro.ad")) {
			System.out.println("/admindeletePro.ad");
			
			adminServiceImpl service = new adminServiceImpl();
			service.admindeletePro(req, res);
			
			viewpage = "/admin/admindeletePro.jsp";
		// 관리자 주문관리
		}else if(url.equals("/adminOrderList.ad")) {
			System.out.println("/adminOrderList.ad");
			
			adminServiceImpl service = new adminServiceImpl();
			service.adminOrderPro(req, res);
			
			viewpage = "/admin/adminOrderList.jsp";
		// 구매승인 클릭시
		}else if(url.equals("/buyok.ad")) {
			System.out.println("/buyok.ad");
			
			adminServiceImpl service = new adminServiceImpl();
			service.buyok(req, res);
			
			viewpage="/admin/buyok.jsp";
		//관리자 환불목록
		}else if(url.equals("/adminrefund.ad")) {
			System.out.println("/adminrefund.ad");
			
			adminServiceImpl service = new adminServiceImpl();
			service.adminrefund(req, res);
			
			viewpage="admin/adminrefund.jsp";
		// 고객 환불요청 처리
		}else if(url.equals("/refundOK.ad")) {
			System.out.println("/refundOK.ad");
			
			adminServiceImpl service = new adminServiceImpl();
			service.refundOK(req, res);
			
			viewpage="admin/refundOK.jsp";
		// 총결산
		}else if(url.equals("/account.ad")) {
			System.out.println("/account.ad");
			
			adminServiceImpl service = new adminServiceImpl();
			service.accountPro(req, res);
			
			viewpage="admin/account.jsp";
		}
		
		
		
		RequestDispatcher dispatcher = req.getRequestDispatcher(viewpage);
		dispatcher.forward(req, res);
	}
}