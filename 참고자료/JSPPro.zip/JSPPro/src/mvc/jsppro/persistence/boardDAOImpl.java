package mvc.jsppro.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import mvc.jsppro.vo.BoardVO;

public class boardDAOImpl implements boardDAO {
	// 커넥션풀 객체 보관
	DataSource datasource;
	
	// 싱글톤방식으로 객체 생성
	private static boardDAOImpl instance = new boardDAOImpl();
	
	public static boardDAOImpl getInstance() {
		return instance;
	}
	// 커넥션풀 사용
	private boardDAOImpl() {
		try {
			Context context = new InitialContext();
			datasource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g_project"); //java:comp/env/resource name
		}catch(Exception e) {
			e.printStackTrace();
	}
}
	// 게시글갯수 구하기
	@Override
	public int getArticleCnt() {
		int selectCnt = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = datasource.getConnection();
			String sql = "SELECT COUNT(*) FROM JSP_board";
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) { //존재한다면
					selectCnt = rs.getInt(1);
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					if(rs != null) rs.close();
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
			return selectCnt;
	}
	// 게시글 목록
	@Override
	public ArrayList<BoardVO> getArticleList(int start, int end) {
		
		// 큰바구니 선언
		ArrayList<BoardVO> dtos = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = datasource.getConnection();
			String sql = "SELECT * " +
					"FROM( SELECT num, writer, pwd, subject, content, readCnt, " +
							"ref, ref_step, ref_level, reg_date, ip, rownum rNum " +
						"FROM(" +
						 		"SELECT * FROM JSP_board " +
						 		"ORDER BY ref DESC, ref_step ASC" + //1. 최신글부터 SELECT
						 	 ")" + //2. 최신글부터 SELECT한 레코드에 rowNum을 추가한다.(삭제데이터를 제외한 실제데이터를 최신글부터 넘버링)
						 ")" +
					"WHERE rNum >= ? AND rNum <= ?"; //3. 넘겨받은 start값 end값으로 rowNum을 조회: 최신1페이지 1~5 / 2페이지 6~10
	pstmt = conn.prepareStatement(sql);
	
	pstmt.setInt(1, start);
	pstmt.setInt(2, end);
	rs = pstmt.executeQuery();
			
	if(rs.next()) {
		// 2. 큰바구니 생성(dtos)
		dtos = new ArrayList<BoardVO>(end - start +1);
		
		//3. 작은 바구니 생성
		do {
			BoardVO dto = new BoardVO();
			
			// 4. 게시글 1건을 읽어서 rs를 작은 바구니(dto)에 담겠다.
			dto.setNum(rs.getInt("num"));
			dto.setWriter(rs.getString("writer"));
			dto.setPwd(rs.getString("pwd"));
			dto.setSubject(rs.getString("subject"));
			dto.setContent(rs.getString("content"));
			dto.setReadCnt(rs.getInt("readcnt"));
			dto.setRef(rs.getInt("ref"));
			dto.setRef_step(rs.getInt("ref_step"));
			dto.setRef_level(rs.getInt("ref_level"));
			dto.setReg_date(rs.getTimestamp("reg_date"));
			dto.setIp(rs.getString("ip"));
			
			// 5. 큰 바구니에(ArrayList dtos)에 작은 바구니(dto, 게시글 1건씩)(추가) 담는다.
			dtos.add(dto);
		}while(rs.next());
	}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(conn != null) conn.close();
				if(pstmt != null) pstmt.close();
				if(rs != null) rs.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
	// 조회수 증가
	@Override
	public void addReadCnt(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = datasource.getConnection();
			String sql = "UPDATE JSP_board SET readCnt=readCnt+1 WHERE num =?";
			pstmt = conn.prepareStatement(sql);	
			pstmt.setInt(1, num);
			
			pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(conn != null) conn.close();
				if(pstmt != null) pstmt.close();	
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
	// 상세페이지 조회
	@Override
	public BoardVO getArticle(int num) {
		BoardVO dto = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = datasource.getConnection();
			String sql = "SELECT * FROM JSP_board WHERE num = ?";
			pstmt = conn.prepareStatement(sql);	
			pstmt.setInt(1, num);
			
			rs = pstmt.executeQuery();
			
			//1. 작은 바구니 생성
			if(rs.next()) {
				dto = new BoardVO();
				
			//2. 게시글 1건을 읽어서 작은 바구니엑 컬럼별로 담는다.
				dto.setNum(rs.getInt("num")); //
				dto.setWriter(rs.getString("writer"));
				dto.setPwd(rs.getString("pwd"));
				dto.setSubject(rs.getString("subject"));
				dto.setContent(rs.getString("content"));
				dto.setReadCnt(rs.getInt("readCnt"));
				dto.setRef(rs.getInt("ref"));
				dto.setRef_step(rs.getInt("ref_step"));
				dto.setRef_level(rs.getInt("ref_level"));
				dto.setReg_date(rs.getTimestamp("reg_date"));
				dto.setIp(rs.getString("ip"));	
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		
		// 3. 작은 바구니(dto)를 리턴한다.
		return dto;
	}
	// 비밀번호 확인(게시글 수정, 게시글 삭제) 여기 할차례 수요일
	@Override
	public int pwdCheck(int num, String strPwd) {
		int selectCnt = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// num과 일치값이 존재하면
		
			// pwd 일치하면 selectCnt =1
		try {
			conn = datasource.getConnection();
			String sql= "SELECT * FROM JSP_board WHERE num = ? AND pwd =?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.setString(2, strPwd);
			
			rs = pstmt.executeQuery();
			if(rs.next()) {
				// num과 일치값이 존재하고, pwd 일치하면 selectCnt =1
				/*if(strPwd.equals(rs.getString("pwd"))) {
					selectCnt = 1;
				}*/
				selectCnt = 1;
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return selectCnt;
	}
	@Override
	public int updateBoard(BoardVO dto) {
		int updateCnt = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = datasource.getConnection();
			String sql = "UPDATE JSP_board SET subject=?, content=?, pwd=? WHERE num=?";
			pstmt = conn.prepareStatement(sql);	
			pstmt.setString(1, dto.getSubject());
			pstmt.setString(2, dto.getContent());
			pstmt.setString(3, dto.getPwd());
			pstmt.setInt(4, dto.getNum());
			
			updateCnt = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(conn != null) conn.close();
				if(pstmt != null) pstmt.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		return updateCnt;
	}
	// 글작성/답글 처리페이지
	@Override
	public int insertBoard(BoardVO dto) {
		int insertCnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		
		try {
			conn = datasource.getConnection();
			
			int num = dto.getNum();
			int ref = dto.getRef();
			int ref_step = dto.getRef_step();
			int ref_level = dto.getRef_level();
			
			// 답변글이 아닌 경우(제목글인 경우)
			if(num == 0) {
				sql = "SELECT MAX(num) FROM JSP_board";//최신글부터 가져온다. (최신글부터 뿌려주므로 게시글작성시 글번호는 최신글번호이어야 한다.	
				pstmt = conn.prepareStatement(sql);
				rs = pstmt.executeQuery();
				
				// 첫글이 아닌 경우
				if(rs.next()) {
					ref = rs.getInt(1) + 1; //ref = MAX(num) + 1;
					System.out.println("--- 첫글이 아닌 경우---");
				// 첫글인 경우
				} else {
					ref = 1;
					System.out.println("--- 첫글인 경우---");
				}
				ref_step = 0;
				ref_level = 0;
			// 답변글인 경우
			}else {
				// 삽입할 글보다 아래쪽 글들의 ref_step 즉 행이 1증가..행을 update 
				sql = "UPDATE JSP_board SET ref_step = ref_step+1 WHERE ref=? AND ref_step > ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, ref);
				pstmt.setInt(2, ref_step);
				
				pstmt.executeUpdate();
				
				ref_step++;
				ref_level++;
			}
			
			sql = "INSERT INTO JSP_board(num,writer, pwd, subject, content, readCnt, ref, ref_step, ref_level, reg_date, ip)"
					+ "VALUES(board_seq.NEXTVAL, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?)";
			pstmt.close();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getWriter());
			pstmt.setString(2, dto.getPwd());
			pstmt.setString(3, dto.getSubject());
			pstmt.setString(4, dto.getContent());
			pstmt.setInt(5, ref);
			pstmt.setInt(6, ref_step);
			pstmt.setInt(7, ref_level);
			pstmt.setTimestamp(8, dto.getReg_date());
			pstmt.setString(9, dto.getIp());
			
			insertCnt = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(conn != null) conn.close();
				if(pstmt != null) pstmt.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return insertCnt;
	}
	// 삭제처리 페이지
	@Override
	public int deleteBoard(int num) {
		int deleteCnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		
		try {
			conn = datasource.getConnection();
			sql ="SELECT * FROM JSP_board WHERE num=?";
			pstmt = conn.prepareStatement(sql);	
			pstmt.setInt(1, num);
			
			rs = pstmt.executeQuery();
			
			// 넘겨받은 num에 해당하는 키값이 존재하면
			if(rs.next()) {
				int ref = rs.getInt("ref");
				int ref_step = rs.getInt("ref_step");
				int ref_level = rs.getInt("ref_level");
			
			// 답글이 존재하는지 여부
			sql = "SELECT * FROM JSP_board WHERE ref=? AND ref_step=?+1 AND ref_level > ?";	
			pstmt.close();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, ref);
			pstmt.setInt(2, ref_step);
			pstmt.setInt(3, ref_level);	
			
			rs.close();
			rs = pstmt.executeQuery();
			
			// 답글이 존재하는 경우
			if(rs.next()) {
				sql = "DELETE JSP_board WHERE ref =?";
				pstmt.close();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, ref);
				
				deleteCnt = pstmt.executeUpdate();
				System.out.println("답글이 존재하는 경우 deleteCnt : " + deleteCnt);
				
				sql = "UPDATE JSP_board SET ref_step=ref_step-1 WHERE ref=? AND ref_step > ?";
				pstmt.close();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, ref);
				pstmt.setInt(2, ref_step);
			
			// 답글이 존재하지 않는 경우
			} else {
				sql = "DELETE JSP_board WHERE num = ?";
				pstmt.close();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, num);
				
				deleteCnt = pstmt.executeUpdate();
				System.out.println("답글이 존재하지 않는 경우 deleteCnt : " + deleteCnt);
			}
		}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return deleteCnt;
	}
}
