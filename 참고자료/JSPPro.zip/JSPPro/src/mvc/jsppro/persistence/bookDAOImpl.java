package mvc.jsppro.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import mvc.jsppro.vo.bookVO;
import mvc.jsppro.vo.orderVO;

public class bookDAOImpl implements bookDAO{
	DataSource datasource;
	
	// 싱글톤 방식으로 객체 생성 : 객체를 1번만 생성하겠다.(private 객체 생성)
	// 호출 : MemberDAOImpl dao = MemberDAOImpl.getInstance();
	//		dao.메소드명; 접근한다
	// 다형성 적용: MemberDAO dao = MemberDAOImpl.getInstance();
	// dao.메소드명;
	private static bookDAOImpl instance = new bookDAOImpl();
	
	// static이므로 클래스명.메소드(); MemberDAOImpl.getInstance();
	public static bookDAOImpl getInstance() {
		return instance;
	}
	//생성자
	private bookDAOImpl() {
		try {
			// 커넥션풀: Servers > context.xml의 resource
			// 커넥션 name : jdbc/Oracle11g
			Context context = new InitialContext();
			datasource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g_project"); //찾으러 오겠다.
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	//중복확인
	@Override
	public int idCheck(String strId) {
		int selectCnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = datasource.getConnection(); //커넥션풀을 통해서 가져오겠다
			String sql ="SELECT * FROM JSPPro WHERE id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, strId);
			
			rs = pstmt.executeQuery();
			
			// 입력받은 id가 table에 존재하면 cnt==1, 즉 id 중복/ 존재하지 않으면 cnt==0;
			if(rs.next()) {
				selectCnt  = 1;
			}
			
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null)pstmt.close();
				if(conn != null)conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return selectCnt;
	}
	
	//회원가입 처리
	@Override
	public int insertbook(bookVO vo) {
		int insertCnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = datasource.getConnection();
			String sql = "INSERT INTO JSPPro(id, pwd, name,email) values(?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getPwd());
			pstmt.setString(3, vo.getName());
			pstmt.setString(4, vo.getEmail());
		
			insertCnt = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch (SQLException e){
				e.printStackTrace();
			}
		}
		return insertCnt;
	}
	// 로그인처리
	@Override
	public int idPwdcheck(String strId, String strPwd) {
		int selectCnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = datasource.getConnection();
		
			//로그인 화면에서 입력받은 id가 일치한 데이터가 있는지 확인
			String sql = "SELECT * FROM JSPPro WHERE id=? AND pwd=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, strId);
			pstmt.setString(2, strPwd);
			rs = pstmt.executeQuery();
			System.out.println("strId : "+strId);
			// 로그인한 id에 해당하는 데이터가 있고
			if(rs.next()) {
				//패스워가 일치하면 selectCnt = 1
				if(strPwd.equals(rs.getString("pwd"))) {
					selectCnt = 1;
					System.out.println(selectCnt);
				}
				//패스워드가 일치하지 않으면 selectCnt = -1
				else {
					selectCnt = -1;
					System.out.println(selectCnt);
				}
			} else {
			// 로그인한 id에 해당하는 데이터가 없으면 selectCnt = 0
				selectCnt = 0;
				System.out.println(selectCnt);
			}
			
		}catch(SQLException e){
		e.printStackTrace();
	}finally {
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
		}catch (SQLException e){
			e.printStackTrace();
			}
		}
		return selectCnt;
	}
	//회원탈퇴 처리
	@Override
	public int deleteMember(String strId) {
		int deleteCnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = datasource.getConnection();
			
			String sql = "DELETE FROM JSPPro WHERE id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, strId);
			
			deleteCnt = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) pstmt.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return deleteCnt;
	}
	@Override
	public bookVO getMemberInfo(String strId) {
		
		// 1.바구니 생성
		bookVO vo = new bookVO();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = datasource.getConnection();
			
			String sql = "SELECT * FROM JSPPro WHERE id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, strId);
			rs = pstmt.executeQuery();
			//2. resultSet에 id에 해당하는 1사람의 회원정보가 존재하면
			if(rs.next()) {
				vo.setId(rs.getString("id"));
				vo.setPwd(rs.getString("pwd"));
				vo.setName(rs.getString("name"));
				vo.setEmail(rs.getString("email"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
				if(rs != null) rs.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return vo;
	}
	// 회원정보 처리
	@Override
	public int updateMember(bookVO vo) {
		int updateCnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = datasource.getConnection();
			String sql = "UPDATE JSPPro SET pwd=?, email=? WHERE id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getPwd());
			pstmt.setString(2, vo.getEmail());
			pstmt.setString(3, vo.getId());
			
			updateCnt = pstmt.executeUpdate();

		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return updateCnt;
	}
	// 책목록
	@Override
	public int getArticleCnt() {
		int guestAdd = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = datasource.getConnection(); 
			String sql = "SELECT * FROM ord";
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				guestAdd = rs.getInt(1);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return guestAdd;
		
	}
	// 책목록
	
	@Override
	public ArrayList<bookVO> getbookList(int start, int end) {
		
		// 큰바구니 선언
		ArrayList<bookVO> dtos = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = datasource.getConnection();
			String sql = "SELECT * FROM ad_min";
			pstmt = conn.prepareStatement(sql);
			
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				// 2. 큰바구니 생성(dtos)
				dtos = new ArrayList<bookVO>(end - start +1);
				
				
					
				//3. 작은 바구니 생성
				do {
					bookVO dto = new bookVO();
					
					// 4. 게시글 1건을 읽어서 rs를 작은 바구니(dto)에 담겠다.
					dto.setBookno(rs.getInt("bookno")); 
					dto.setBookname(rs.getString("bookname"));
					dto.setBookauthor(rs.getString("bookauthor"));
					dto.setBookprice(rs.getInt("bookprice"));
					dto.setBookcount(rs.getInt("bookcount"));
					
					// 5. 큰 바구니에(ArrayList dtos)에 작은 바구니(dto, 게시글 1건씩)(추가) 담는다.
					dtos.add(dto);
				}while(rs.next());
			}
			
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(conn != null) conn.close();
				if(pstmt != null) pstmt.close();
				if(rs != null) rs.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		
		return dtos;
	}
	//장바구니 목록
	@Override
	public ArrayList<orderVO> getcartList(int start,int end) {
		ArrayList<orderVO> dtos = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = datasource.getConnection();
			String sql = "SELECT buycount, a.bookno, a.bookname, a.bookauthor, a.bookprice , id , o.o_id, o.o_state,rownum rnum  FROM ad_min a JOIN ord o on a.bookno = o.bookno WHERE o.o_state=1";
			pstmt = conn.prepareStatement(sql);		
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dtos = new ArrayList<orderVO>(end -start +1);
			
				do {
					orderVO dto = new orderVO();
					dto.setO_id(rs.getInt("o_id"));
					dto.setBookno(rs.getInt("bookno"));
					dto.setM_id(rs.getString("id"));
					dto.setO_state(rs.getInt("o_state"));
					dto.setBookname(rs.getString("bookname")); 
					dto.setBookauthor(rs.getString("bookauthor"));
					dto.setBookprice(rs.getInt("bookprice"));
					dto.setBuycount(rs.getString("buycount"));
					dtos.add(dto);
				}while(rs.next());
				
				
		}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(conn != null) conn.close();
				if(pstmt != null) pstmt.close();
				if(rs != null) rs.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
	//장바구니 추가
	@Override
	public int insertOrder(String id, int bookno, String buycount) {
		int insertOrder = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		
		
		try {
			conn = datasource.getConnection();
			sql = "INSERT INTO ord(o_id, bookno, id, o_state, buycount)"
					+ "VALUES(ord_seq.NEXTVAL, ?, ?, 1, ?)";
			pstmt = conn.prepareStatement(sql);	
			pstmt.setInt(1, bookno);
			pstmt.setString(2, id);
			pstmt.setString(3, buycount);
			
			insertOrder = pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return insertOrder;
	}
	//장바구니 삭제
	@Override
	public int deletecart(int o_id) {
		int deleteCnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = datasource.getConnection();
			
			String sql = "DELETE FROM ord WHERE o_id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, o_id);
			
			deleteCnt = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) pstmt.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return deleteCnt;
	}
	//장바구니 구매
	@Override
	public int cartbuyPro(orderVO dto) {
		int updateCnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = datasource.getConnection();
			int o_id =  dto.getO_id();
			int bookno = dto.getBookno();
			String buycount = dto.getBuycount();
			String id = dto.getM_id();
			
			
			String sql ="UPDATE ord SET o_state=2 WHERE o_id=? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, o_id);
			
			updateCnt = pstmt.executeUpdate();
			
			pstmt.close();
			
			 sql = "UPDATE ad_min SET bookcount-? WHERE bookno=?";
				pstmt.close();
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, buycount);
				pstmt.setInt(2, bookno);
				
				pstmt.executeUpdate();

		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) pstmt.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return updateCnt;
	}
	//주문내역
	@Override
	public ArrayList<orderVO> orderList(String memId) {
		ArrayList<orderVO> dtos = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = datasource.getConnection();
			String sql = "SELECT a.bookno, buycount, a.bookname, a.bookauthor, a.bookprice , id, o.o_id, o.o_state,rownum rnum  FROM ad_min a JOIN ord o on a.bookno = o.bookno WHERE id=? ";

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, memId);
			
			rs = pstmt.executeQuery();		
			
			if (rs.next()) {
				// 2. 큰 바구니 생성(dtos)
				dtos = new ArrayList<orderVO>();

				do { // 반드시 한번은 바구니를 생성해야하기때문에 do-while 태운다.
						// 3. 작은 바구니 생성
					orderVO dto = new orderVO();
					// 4. 게시글 1건을 읽어서 rs를 작은바구니(=dto)에 담는다.
					dto.setO_id(rs.getInt("o_id"));
					dto.setBookno(rs.getInt("bookno"));
					dto.setO_state(rs.getInt("o_state"));
					dto.setM_id(rs.getString("id"));
					dto.setBookname(rs.getString("bookname")); 
					dto.setBuycount(rs.getString("buycount")); 
					dto.setBookauthor(rs.getString("bookauthor"));
					dto.setBookprice(rs.getInt("bookprice"));
					// 5. 큰 바구니에(ArrayList dtos)에 작은바구니 (게시글 1건-dto) 담는다.
					dtos.add(dto);

				} while (rs.next()); // 최종적으로 dtos에 5번담게된다.
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
	// 고객환불요청
	@Override
	public int refund(int o_id) {
		int updateCnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		System.out.println("dao1");
		try {
			conn = datasource.getConnection();
			String sql = "SELECT * FROM ord WHERE o_id =?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, o_id);
			System.out.println("dao2");
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				pstmt.close();
				String sql2 = "UPDATE ord SET o_state=4 WHERE o_id =?";
				pstmt = conn.prepareStatement(sql2);
				pstmt.setInt(1, o_id);
				System.out.println("dao3");
				updateCnt = pstmt.executeUpdate();
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("dao4");
		return updateCnt;
	}
}
