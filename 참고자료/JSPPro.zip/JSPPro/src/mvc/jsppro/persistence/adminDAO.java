package mvc.jsppro.persistence;

import java.util.ArrayList;

import mvc.jsppro.vo.adminVO;
import mvc.jsppro.vo.orderVO;

public interface adminDAO {
	// 관리자 재고관리 구하기
	public int getArticleCnt();
	
	// 관리자 재고관리 목록 조회
	public ArrayList<adminVO> getArticleList(int start, int end);
	
	// 관리자 재고관리 추가 페이지
	public int insertadmin(adminVO dto);
	
	// 관리자 재고관리 상세페이지 조회
	public adminVO getArticle(int bookno);
	
	// 재고관리 수정확인
	public int modifyCheck(int bookno);
	
	// 재고관리 수정 처리페이지
	public int updateadmin(adminVO dto);
	
	// 재고관리 삭제 처리페이지
	public int deleteadmin(int bookno);
	
	// 주문관리목록
	public ArrayList<orderVO> orderadmin();
	
	// 관리자 구매승인 클릭 시
	public int buyok(int o_id, int buycount, int bookno);
	
	// 관리자 환불
	public int getArticleCnt1();
	
	//관리자 환불 목록
	public ArrayList<orderVO> getArticleList1(int start, int end);
	
	// 관리자 환불승인 클릭시
	public int refundOK(int o_id, int buycount, int bookno);
	
	//결산내역 확인
	public ArrayList<orderVO> account();
}
