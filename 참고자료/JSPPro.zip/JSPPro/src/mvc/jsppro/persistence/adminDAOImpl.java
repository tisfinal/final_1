package mvc.jsppro.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import mvc.jsppro.vo.BoardVO;
import mvc.jsppro.vo.adminVO;
import mvc.jsppro.vo.bookVO;
import mvc.jsppro.vo.orderVO;


public class adminDAOImpl implements adminDAO{
	
	// 커넥션풀 객체 보관
	DataSource datasource;
	
	// 싱글톤방식으로 객체 생성
	private static adminDAOImpl instance = new adminDAOImpl();
	
	public static adminDAOImpl getInstance() {
		return instance;
	}
	
	// 커넥션풀 사용
	private adminDAOImpl() {
		try {
			Context context = new InitialContext();
			datasource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g_project"); //java:comp/env/resource name
		}catch(Exception e) {
			e.printStackTrace();
	}
}
	// 관리자 재고관리 구하기
	@Override
	public int getArticleCnt() {
		int selectCnt = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = datasource.getConnection(); 
			String sql = "SELECT COUNT(*) FROM ad_min";
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) { //존재한다면
				System.out.println(selectCnt);
				selectCnt = rs.getInt(1);
				System.out.println(selectCnt);
			}
			System.out.println(selectCnt);
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return selectCnt;
	}
	
	// 관리자 재고관리 목록 조회
	@Override
	public ArrayList<adminVO> getArticleList(int start, int end) {
		// 큰바구니 선언
		ArrayList<adminVO> dtos = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = datasource.getConnection();
			String sql = "SELECT * FROM(SELECT bookno, bookname, bookauthor, bookkind, bookintrod, bookprice, bookcount, bookreg_date, rownum rNum FROM(SELECT * FROM ad_min	ORDER BY bookreg_date))WHERE rNum >= ? AND rNum <= ?";			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				// 2. 큰바구니 생성(dtos)
				dtos = new ArrayList<adminVO>(end - start +1);
			
			//3. 작은 바구니 생성
			do {
				adminVO dto = new adminVO();
				
				// 4. 게시글 1건을 읽어서 rs를 작은 바구니(dto)에 담겠다.
				dto.setBookno(rs.getInt("bookno"));
				dto.setBookname(rs.getString("bookname"));
				dto.setBookauthor(rs.getString("bookauthor"));
				dto.setBookkind(rs.getString("bookkind"));
				dto.setBookintrod(rs.getString("bookintrod"));
				dto.setBookprice(rs.getInt("bookprice"));
				dto.setBookcount(rs.getInt("bookcount"));
				dto.setBookreg_date(rs.getTimestamp("bookreg_date"));
				// 5. 큰 바구니에(ArrayList dtos)에 작은 바구니(dto, 게시글 1건씩)(추가) 담는다.
				dtos.add(dto);
			}while(rs.next());
		}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		//6. 큰바구니를 (dtos) 를return
		return dtos;
	}
	// 관리자 재고관리 추가 페이지
	@Override
	public int insertadmin(adminVO dto) {
		int insertCnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		
		try {
			conn = datasource.getConnection();
			sql = "INSERT INTO ad_min(bookno, bookname, bookauthor, bookkind, bookintrod, bookprice, bookcount, bookreg_date) "
					 + "VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, dto.getBookno());
			pstmt.setString(2, dto.getBookname());
			pstmt.setString(3, dto.getBookauthor());
			pstmt.setString(4, dto.getBookkind());
			pstmt.setString(5, dto.getBookintrod());
			pstmt.setInt(6, dto.getBookprice());
			pstmt.setInt(7, dto.getBookcount());
			pstmt.setTimestamp(8, dto.getBookreg_date());
			
			insertCnt = pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return insertCnt;
	}
	// 관리자 재고관리 상세페이지 조회
	@Override
	public adminVO getArticle(int bookno) {
		adminVO dto = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = datasource.getConnection();
			String sql = "SELECT * FROM ad_min WHERE bookno=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bookno);

			rs = pstmt.executeQuery();
			
			//1. 작은 바구니 생성
			if(rs.next()) {
				dto = new adminVO();
				
			//
				dto.setBookno(rs.getInt("bookno"));
				dto.setBookname(rs.getString("bookname"));
				dto.setBookauthor(rs.getString("bookauthor"));
				dto.setBookkind(rs.getString("bookkind"));
				dto.setBookintrod(rs.getString("bookintrod"));
				dto.setBookprice(rs.getInt("bookprice"));
				dto.setBookcount(rs.getInt("bookcount"));
				dto.setBookreg_date(rs.getTimestamp("bookreg_date"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return dto;
	}
	// 재고관리 수정확인
	@Override
	public int modifyCheck(int bookno) {
		int selectCnt = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = datasource.getConnection();
			String sql = "SELECT * FROM ad_min WHERE bookno =?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bookno);

			rs = pstmt.executeQuery();
			if(rs.next()) {
				selectCnt = 1;
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return selectCnt;
	}
	// 재고관리 수정처리페이지
	@Override
	public int updateadmin(adminVO dto) {
		int updateCnt = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = datasource.getConnection();
			String sql = "UPDATE ad_min SET bookname=?, bookauthor=?, bookkind=?, bookintrod=?, bookprice=?, bookcount=? WHERE bookno=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getBookname());
			pstmt.setString(2, dto.getBookauthor());
			pstmt.setString(3, dto.getBookkind());
			pstmt.setString(4, dto.getBookintrod());
			pstmt.setInt(5, dto.getBookprice());
			pstmt.setInt(6, dto.getBookcount());
			pstmt.setInt(7, dto.getBookno());
			
			updateCnt = pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(conn != null) conn.close();
				if(pstmt != null) pstmt.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return updateCnt;
	}
	// 관리자 재고 삭제 처리페이지
	@Override
	public int deleteadmin(int bookno) {
		int deleteCnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = null;
		
		try {
			conn = datasource.getConnection();
			sql = "DELETE ad_min WHERE bookno =?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bookno);
			deleteCnt = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		
		return deleteCnt;
	}
	// 관리자 주문관리 목록
	@Override
	public ArrayList<orderVO> orderadmin() {
		ArrayList<orderVO> dtos = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = datasource.getConnection();

			/*String sql ="SELECT o.o_id, a.bookno, a.bookname, a.bookauthor, a.bookprice, o.buycount FROM ord o JOIN ad_min a ON o.bookno = a.bookno WHERE o.state =2";*/
			/*String sql = "SELECT a.bookno, buycount, a.bookname, a.bookauthor, a.bookprice , id , o.o_id, o.o_state,rownum rnum  FROM ad_min a JOIN ord o on a.bookno = o.bookno WHERE= o_state=2";*/
			String sql = "SELECT a.bookno, buycount, a.bookname, a.bookauthor, a.bookprice , id, o.o_id, o.o_state FROM ad_min a JOIN ord o on a.bookno = o.bookno WHERE o.o_state = 2";
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();		
			System.out.println("dao1");
			if (rs.next()) {
				// 2. 큰 바구니 생성(dtos)
				dtos = new ArrayList<orderVO>();

				do { // 반드시 한번은 바구니를 생성해야하기때문에 do-while 태운다.
						// 3. 작은 바구니 생성
					orderVO dto = new orderVO();
					// 4. 게시글 1건을 읽어서 rs를 작은바구니(=dto)에 담는다.
					dto.setO_id(rs.getInt("o_id"));
					dto.setBookno(rs.getInt("bookno"));
					dto.setO_state(rs.getInt("o_state"));
					dto.setM_id(rs.getString("id"));
					dto.setBookname(rs.getString("bookname")); 
					dto.setBuycount(rs.getString("buycount")); 
					dto.setBookauthor(rs.getString("bookauthor"));
					dto.setBookprice(rs.getInt("bookprice"));
					System.out.println("dao2");
					// 5. 큰 바구니에(ArrayList dtos)에 작은바구니 (게시글 1건-dto) 담는다.
					dtos.add(dto);

				} while (rs.next()); // 최종적으로 dtos에 5번담게된다.
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("dao3");
		return dtos;
	}
	// 구매승인처리 페이지
	@Override
	public int buyok(int o_id, int buycount, int bookno) {
		int updateCnt=0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		System.out.println("dao1");
		try {
			conn = datasource.getConnection();
			String sql = "UPDATE ad_min SET bookcount=bookcount-? WHERE bookno=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, buycount);
			pstmt.setInt(2, bookno);
			System.out.println("dao2");
			
			updateCnt = pstmt.executeUpdate();
			
			System.out.println("????" + updateCnt);
			if(updateCnt == 1) {
				pstmt.close();
				
				System.out.println("dao3");
				String sql2 = "UPDATE ord SET o_state = 3 WHERE o_id = ?";
				pstmt = conn.prepareStatement(sql2);
				pstmt.setInt(1, o_id);
				System.out.println("dao4");
				updateCnt = pstmt.executeUpdate();
				
			}

			
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		
		System.out.println("dao5");
		return updateCnt;
	}

	// 관리자 환불목록
	@Override
	public int getArticleCnt1() {
		int selectCnt = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = datasource.getConnection(); 
			String sql = "SELECT COUNT(*) FROM ord";
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) { //존재한다면
				System.out.println(selectCnt);
				selectCnt = rs.getInt(1);
				System.out.println(selectCnt);
			}
			System.out.println(selectCnt);
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return selectCnt;
	}
	// 관리자 환불목록
	@Override
	public ArrayList<orderVO> getArticleList1(int start, int end) {
		ArrayList<orderVO> dtos = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = datasource.getConnection();
			String sql = "SELECT a.bookno, buycount, a.bookname, a.bookauthor, a.bookprice , id, o.o_id, o.o_state FROM ad_min a JOIN ord o on a.bookno = o.bookno WHERE o.o_state = 4";			
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dtos = new ArrayList<orderVO>(end - start +1);
				
				do {
					orderVO dto =new orderVO();
					dto.setO_id(rs.getInt("o_id"));
					dto.setBookno(rs.getInt("bookno"));
					dto.setO_state(rs.getInt("o_state"));
					dto.setM_id(rs.getString("id"));
					dto.setBookname(rs.getString("bookname")); 
					dto.setBuycount(rs.getString("buycount")); 
					dto.setBookauthor(rs.getString("bookauthor"));
					dto.setBookprice(rs.getInt("bookprice"));
				
					dtos.add(dto);
				}while(rs.next());
			}
		
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}

	@Override
	public int refundOK(int o_id, int buycount, int bookno) {
		int selectCnt=0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		System.out.println("dao1");
		try {
			conn = datasource.getConnection();
			String sql = "UPDATE ad_min SET bookcount=bookcount+? WHERE bookno=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, buycount);
			pstmt.setInt(2, bookno);
			System.out.println("dao2");
			
			selectCnt = pstmt.executeUpdate();
			
			System.out.println("????" + selectCnt);
			if(selectCnt == 1) {
				pstmt.close();
				
				System.out.println("dao3");
				String sql2 = "UPDATE ord SET o_state = 5 WHERE o_id = ?";
				pstmt = conn.prepareStatement(sql2);
				pstmt.setInt(1, o_id);
				System.out.println("dao4");
				selectCnt = pstmt.executeUpdate();
				
			}

			
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		System.out.println("dao5");
		return selectCnt;
	}
	// 결산
	@Override
	public ArrayList<orderVO> account() {
		ArrayList<orderVO> dtos = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = datasource.getConnection();
			String sql = "SELECT a.bookno, a.bookname, a.bookauthor, a.bookprice , id, o.o_id, o.buycount FROM ad_min a JOIN ord o on a.bookno = o.bookno WHERE o_state=3";			
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dtos = new ArrayList<orderVO>();
				
				do {
					orderVO dto =new orderVO();
					dto.setO_id(rs.getInt("o_id"));
					dto.setBookno(rs.getInt("bookno"));
					dto.setM_id(rs.getString("id"));
					dto.setBookname(rs.getString("bookname")); 
					dto.setBuycount(rs.getString("buycount")); 
					dto.setBookauthor(rs.getString("bookauthor"));
					dto.setBookprice(rs.getInt("bookprice"));
				
					dtos.add(dto);
				}while(rs.next());
			}
		
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
}
