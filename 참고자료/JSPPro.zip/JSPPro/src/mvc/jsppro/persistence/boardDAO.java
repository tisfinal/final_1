package mvc.jsppro.persistence;

import java.util.ArrayList;

import mvc.jsppro.vo.BoardVO;


public interface boardDAO {
	
	// 글 갯수 구하기
	public int getArticleCnt();
	
	// 게시글 목록 조회
	public ArrayList<BoardVO> getArticleList(int start, int end);
	
	// 조회수 증가
	public void addReadCnt(int num);
	
	// 상세페이지 조회
	public BoardVO getArticle(int num);
	
	// 비밀번호 확인(게시글 수정, 게시글 삭제)
	public int pwdCheck(int num, String strPwd);
	
	// 글수정 처리
	public int updateBoard(BoardVO dto);
	
	// 글작성/답글 처리페이지 
	public int insertBoard(BoardVO dto);
	
	// 글삭제 처리페이지
	public int deleteBoard(int num);
	
}
