package mvc.jsppro.persistence;


import java.util.ArrayList;

import mvc.jsppro.vo.bookVO;
import mvc.jsppro.vo.orderVO;
public interface bookDAO {
	
	// 중복확인 체크
	public int idCheck(String strId);
	
	// 회원가입 처리
	public int insertbook(bookVO vo);
	
	// 로그인 처리, 회원탈퇴처리 전, 회원수정처리 전
	public int idPwdcheck(String strId, String strPwd);
	
	// 회원탈퇴 처리
	public int deleteMember(String strId);
	
	// 회원정보 상세페이지
	public bookVO getMemberInfo(String strId);
	
	// 회원정보 처리
	public int updateMember(bookVO vo);
	
	// 고객 장바구니 목록 구하기
	public int getArticleCnt();
	
	// 고객 장바구니 목록 조회
	public ArrayList<bookVO> getbookList(int start, int end);
	
	// 장바구니에 넘기기
	public ArrayList<orderVO> getcartList(int start, int end);
	
	// 장바구니 추가
	public int insertOrder(String id, int bookno, String buycount);
	
	// 장바구니 삭제
	public int deletecart(int o_id);
	
	//장바구니 구매
	public int cartbuyPro(orderVO dto);
	
	//총주문내역
	public ArrayList<orderVO> orderList(String memId);
	
	public int refund(int o_id);
}
