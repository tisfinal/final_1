package mvc.jsppro.servicecon;

import java.sql.Timestamp;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.jsppro.persistence.boardDAO;
import mvc.jsppro.persistence.boardDAOImpl;
import mvc.jsppro.vo.BoardVO;

public class boardServiceImpl implements boardService{

	@Override
	public void boardList(HttpServletRequest req, HttpServletResponse res) {
		// 3단계 화면으로부터 입력받은 값을 받아온다.
		// 게시판 관련
		int pageSize = 5;		//한 페이지당 출력할 글 갯수
		int pageBlock = 3; 		// 한 블럭당 페이지 갯수
		
		int cnt = 0;			// 글 갯수
		int start = 0;			// 현재 페이지 시작 글번호
		int end = 0;			// 현재 페이지 마지막 글번호
		int number = 0; 		// 출력용 글번호
		String pageNum = null;	// 페이지 번호
		int currentPage = 0;	// 현재 페이지
		
		int pageCount = 0;		// 페이지 갯수
		int startPage = 0;		// 시작 페이지
		int endPage = 0;		// 마지막 페이지
		
		// 4단계 다형성 적용, 싱글톤 방식으로 dao 객체 생성
		boardDAO dao = boardDAOImpl.getInstance();
		
		// 5단계. 글갯수 구하기
		cnt = dao.getArticleCnt();
		System.out.println("cnt :" + cnt); // 먼저 테이블에 30건을 insert 할것
		
		// 6단계 request나 session에 처리 결과를 저장(jsp에 전달하기 위함).
		pageNum = req.getParameter("pageNum");
		
		if(pageNum == null) {
			pageNum = "1"; // 첫페이지 1페이지로 설정
		}
		
		// 글 30건 기준
		currentPage = Integer.parseInt(pageNum); // 현재 페이지 : 1
			System.out.println("currentPage" + currentPage);
		
		// 페이지 갯수 6 = (30 / 5) + (0)
		pageCount = (cnt / pageSize) + (cnt % pageSize > 0 ? 1 : 0); // 페이지 갯수 + 나머지있으면1
		
		// 1 = (1 - 1) * 5 + 1
		start = (currentPage - 1) * pageSize + 1; // 현재 페이지 시작번호 1
		
		// 5 = 1 + 5 - 1;
		end = start + pageSize - 1; // 현재 페이지 끝번호 5
			System.out.println("start : " + start);
			System.out.println("end : " + end);
		
		if(end > cnt) end = cnt;
		
		// 30 = 30 - (1 - 1) * 5
		number = cnt - (currentPage - 1) * pageSize; // 출력용 글번호
		
			System.out.println("number : " + number);
			System.out.println("pageSize : " + pageSize);
		
		if(cnt > 0) {
			// 게시글 목록 조회
			ArrayList<BoardVO> dtos = dao.getArticleList(start,end);
			req.setAttribute("dtos" ,dtos); //큰바구니 : 게시글목록을 넘겼다 cf)작은 바구니 : 게시글 1건
			
		}
		
		// 1 = (1 / 3) * 3 + 1
		startPage = (currentPage / pageBlock) * pageBlock + 1; // 시작 페이지
		if(currentPage % pageBlock == 0) startPage -= pageBlock; 
			System.out.println("startPage : " + startPage);
		
		// 3 = + 1 + 3 - 1
		endPage = startPage + pageBlock - 1; // 마지막 페이지
		if(endPage > pageCount) endPage = pageCount;
			System.out.println("endPage : " + endPage);
			
			req.setAttribute("cnt", cnt);			// 글갯수
			req.setAttribute("number", number);		// 글번호
			req.setAttribute("pageNum", pageNum);	// 페이지 번호
		
		if(cnt > 0) {
			req.setAttribute("startPage", startPage); // 시작 페이지
			req.setAttribute("endPage", endPage);	  // 마지막 페이지
			req.setAttribute("pageBlock", pageBlock); // 출력할 페이지 갯수
			req.setAttribute("pageCount", pageCount); //페이지 갯수
			req.setAttribute("currentPage" , currentPage); //현재 페이지
		}
	}
	// 상세페이지
	@Override
	public void contentForm(HttpServletRequest req, HttpServletResponse res) {
		
		// 3 단계. 화면으로부터 입력받은 값을 받아온다
		int num = Integer.parseInt(req.getParameter("num"));
		int pageNum = Integer.parseInt(req.getParameter("pageNum"));
		int number = Integer.parseInt(req.getParameter("number"));
	
		// 4단계 다형성 적용, 싱글톤 방식으로 dao 객체 생성 
		boardDAO dao = boardDAOImpl.getInstance();
		
		// 5단계. 조회수 증가
		dao.addReadCnt(num);
		// 5단계. 상세페이지 조회
		BoardVO dto = dao.getArticle(num);

		// 6단계 request나 session에 처리 결과를 저장(jsp에 전달하기 위함).
		req.setAttribute("dto", dto);
		req.setAttribute("pageNum", pageNum);
		req.setAttribute("number", number);
	}	
	// 글수정 상세페이지
	@Override
	public void boardmodifyView(HttpServletRequest req, HttpServletResponse res) {
		
		// 3단계. 화면으로부터 입력받은 값을 받아온다.
		int num = Integer.parseInt(req.getParameter("num"));
		int pageNum = Integer.parseInt(req.getParameter("pageNum"));
		String strPwd = req.getParameter("pwd");
		
		// 4단계. 다형성 적용, 싱글톤 방식으로 dao 객체생성
		boardDAO dao = boardDAOImpl.getInstance();
		
		// 5단계. pwd Check
		int selectCnt = dao.pwdCheck(num, strPwd);
		
		// 5-2단계. selectCnt가 1일때 num과 일치하는 게시글 1건을 읽어온다.
		if(selectCnt == 1) {
			BoardVO dto = dao.getArticle(num);
			req.setAttribute("dto", dto);		
		}
		// 6단계 request나 session에 처리 결과를 저장(jsp에 전달하기 위함).
		req.setAttribute("selectCnt", selectCnt);
		req.setAttribute("num", num);
		req.setAttribute("pageNum", pageNum);
	}
	
	// 글수정 처리페이지
	@Override
	public void boardmodifyPro(HttpServletRequest req, HttpServletResponse res) {
		// 3단계. 화면으로부터 입력받은 값을 받아온다.
		int num = Integer.parseInt(req.getParameter("num"));
		int pageNum = Integer.parseInt(req.getParameter("pageNum"));
		// 바구니 생성
		BoardVO dto =new BoardVO();
		dto.setNum(num);
		dto.setSubject(req.getParameter("subject"));
		dto.setContent(req.getParameter("content"));
		dto.setPwd(req.getParameter("pwd"));
		// 화면에서 입력한 값 (글번호, 제목, 내용, 비밀번호)들을 바구니에 담는다.
		// 4단계. 다형성 적용, 싱글톤 방식으로 dao 객체생성		
		boardDAO dao = boardDAOImpl.getInstance();
		// 5단계. 글수정처리
		int updateCnt = dao.updateBoard(dto);
		// 6단계 request나 session에 처리 결과를 저장(jsp에 전달하기 위함).
		req.setAttribute("num", num);
		req.setAttribute("pageNum", pageNum);
		req.setAttribute("updateCnt", updateCnt);
	}
	@Override
	public void writePro(HttpServletRequest req, HttpServletResponse res) {
		// 바구니 생성
		BoardVO dto = new BoardVO();
		
		// 3단계. 화면(hidden)으로부터 입력받은 값을 받아온다.
		dto.setNum(Integer.parseInt(req.getParameter("num")));
		dto.setRef(Integer.parseInt(req.getParameter("ref")));
		dto.setRef_step(Integer.parseInt(req.getParameter("ref_step")));
		dto.setRef_level(Integer.parseInt(req.getParameter("ref_level")));
		
		// 화면에서 입력한 값(작성자, 제목, 내용, 비밀번호)들을 바구니에 담는다.
		dto.setWriter(req.getParameter("writer"));
		dto.setPwd(req.getParameter("pwd")); 
		dto.setSubject(req.getParameter("subject"));
		dto.setContent(req.getParameter("content"));
		dto.setReg_date(new Timestamp(System.currentTimeMillis()));
		// http://localhost:8081/JSP_mvcBoard/boardList.bo
		// localhost 대신 본인 IP입력
		dto.setIp(req.getRemoteAddr());
		
		// 4단계. 다형성 적용, 싱글톤 방식으로 dao 객체생성
		boardDAO dao = boardDAOImpl.getInstance();

		// 5단계. 글작성/답글 처리페이지 (비즈니스로직)
		int insertCnt = dao.insertBoard(dto); //리턴타입
		
		// 6단계. request나 session에 처리 결과를 저장(jsp에 전달하기 위함).
		req.setAttribute("dto", dto);
		req.setAttribute("insertCnt", insertCnt);
	}
	// 삭제처리 페이지
	@Override
	public void boarddeletePro(HttpServletRequest req, HttpServletResponse res) {
		// 3단계. 화면으로부터 입력받은 값을 받아온다.
		System.out.println("aaaaa");
		int num = Integer.parseInt(req.getParameter("num"));
		int pageNum = Integer.parseInt(req.getParameter("pageNum"));
		String strPwd = req.getParameter("pwd");
		System.out.println(num);
		System.out.println(pageNum);
		// 4단계. 다형성 적용, 싱글톤 방식으로 dao 객체생성
		boardDAO dao = boardDAOImpl.getInstance();
		
		// 5단계. pwd Check
		int selectCnt = dao.pwdCheck(num, strPwd);
		int deleteCnt = 0;
		System.out.println("hi");
		// 5-2단계. 글삭제 처리페이지
		if(selectCnt != 0) {
			deleteCnt = dao.deleteBoard(num);
			
		}
		// 6단계 request나 session에 처리 결과를 저장(jsp에 전달하기 위함).
		req.setAttribute("deleteCnt", deleteCnt);
		req.setAttribute("selectCnt", selectCnt);
		req.setAttribute("pageNum", pageNum);
		System.out.println("deleteCnt : "+deleteCnt);
		System.out.println("seleteCnt : "+selectCnt);
		
	}
}
