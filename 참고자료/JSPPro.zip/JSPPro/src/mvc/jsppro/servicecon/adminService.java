package mvc.jsppro.servicecon;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface adminService {
	
	// 관리자 재고관리
	public void addminList(HttpServletRequest req, HttpServletResponse res);

	// 관리자 재고추가페이지
	public void adminwritePro(HttpServletRequest req, HttpServletResponse res);

	// 관리자 재고 상세페이지 
	public void admincontentFrom(HttpServletRequest req, HttpServletResponse res);
	
	// 관리자 재고 수정 상세페이지
	public void adminmodifyView(HttpServletRequest req, HttpServletResponse res);

	// 관리자 재고 수정 처리페이지
	public void adminmodifyPro(HttpServletRequest req, HttpServletResponse res);

	// 관리자 재고 삭제 처리페이지
	public void admindeletePro(HttpServletRequest req, HttpServletResponse res);
	
	// 관리자 주문관리 요청
	public void adminOrderPro(HttpServletRequest req, HttpServletResponse res);
	
	// 구매승인 클릭 시
	public void buyok(HttpServletRequest req, HttpServletResponse res);
	
	// 관리자 환불
	public void adminrefund(HttpServletRequest req, HttpServletResponse res);

	// 고객 환불 요청 처리
	public void refundOK(HttpServletRequest req, HttpServletResponse res);
	
	// 총결산내역
	public void accountPro(HttpServletRequest req, HttpServletResponse res);
}
