package mvc.jsppro.servicecon;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface bookService {
	
	//중복확인 체크하겠다
	public void confirmID(HttpServletRequest req, HttpServletResponse res);
	
	//회원가입 처리
	public void membershipPro(HttpServletRequest req, HttpServletResponse res);
	
	//로그인 처리
	public void loginPro(HttpServletRequest req, HttpServletResponse res);
	
	//회원탈퇴 
	public void deletePro(HttpServletRequest req, HttpServletResponse res);
	
	//회원정보 수정 상세페이지
	public void modifyView(HttpServletRequest req, HttpServletResponse res);
	
	// 회원정보 수정 처리
	public void modifyPro(HttpServletRequest req, HttpServletResponse res);
	
			// 고객 장바구니  cartVO
	// 책목록
	public void booklist(HttpServletRequest req, HttpServletResponse res);
	
	// 책목록 장바구니에 넘기기
	public void cartlist(HttpServletRequest req, HttpServletResponse res);
	
	//장바구니 추가
	public void cartPro(HttpServletRequest req, HttpServletResponse res);
	
	//장바구니 삭제
	public void cartdelete(HttpServletRequest req, HttpServletResponse res);
	
	//장바구니 구매
	public void cartbuy(HttpServletRequest req, HttpServletResponse res);
	
	// 구매 목록
	public void orderList(HttpServletRequest req, HttpServletResponse res);

	//고객 환불요청
	public void refund(HttpServletRequest req, HttpServletResponse res);
	
}
