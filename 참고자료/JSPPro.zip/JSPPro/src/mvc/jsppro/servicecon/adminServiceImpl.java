package mvc.jsppro.servicecon;

import java.sql.Timestamp;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.jsppro.persistence.adminDAO;
import mvc.jsppro.persistence.adminDAOImpl;
import mvc.jsppro.persistence.bookDAO;
import mvc.jsppro.persistence.bookDAOImpl;
import mvc.jsppro.vo.adminVO;
import mvc.jsppro.vo.orderVO;

public class adminServiceImpl implements adminService {
	
	
	//관리자 재고관리 목록
	@Override
	public void addminList(HttpServletRequest req, HttpServletResponse res) {
		// 3단계 화면으로부터 입력받은 값을 받아온다.
		// 게시판 관련
		int pageSize = 5;		//한 페이지당 출력할 책 갯수
		int pageBlock = 3; 		// 한 블럭당 페이지 갯수
		
		int cnt = 0;			// 책 갯수
		int start = 0;			// 현재 페이지 시작 책번호
		int end = 0;			// 현재 페이지 마지막 책번호
		int number = 0; 		// 출력용 책번호
		String pageNum = null;	// 페이지 번호
		int currentPage = 0;	// 현재 페이지
		
		int pageCount = 0;		// 페이지 갯수
		int startPage = 0;		// 시작 페이지
		int endPage = 0;		// 마지막 페이지
		
		// 4단계 다형성 적용, 싱글톤 방식으로 dao 객체 생성
		adminDAO dao = adminDAOImpl.getInstance();
		
		// 5단계. 글갯수 구하기
		cnt = dao.getArticleCnt();
		System.out.println("cnt :" + cnt);
		
		// 6단계 request나 session에 처리 결과를 저장(jsp에 전달하기 위함).
			pageNum = req.getParameter("pageNum");
			
			if(pageNum == null) {
				pageNum = "1"; // 첫페이지 1페이지로 설정
			}
			
			// 글 30건 기준
			currentPage = Integer.parseInt(pageNum); // 현재 페이지 : 1
				System.out.println("currentPage" + currentPage);
			
			// 페이지 갯수 6 = (30 / 5) + (0)
			pageCount = (cnt / pageSize) + (cnt % pageSize > 0 ? 1 : 0); // 페이지 갯수 + 나머지있으면1
			
			// 1 = (1 - 1) * 5 + 1
			start = (currentPage - 1) * pageSize + 1; // 현재 페이지 시작번호 1
			
			// 5 = 1 + 5 - 1;
			end = start + pageSize - 1; // 현재 페이지 끝번호 5
				System.out.println("start : " + start);
				System.out.println("end : " + end);
			
			if(end > cnt) end = cnt;
			
			// 30 = 30 - (1 - 1) * 5
			number = cnt - (currentPage - 1) * pageSize; // 출력용 글번호
			
				System.out.println("number : " + number);
				System.out.println("pageSize : " + pageSize);
			
			if(cnt > 0) {
				// 게시글 목록 조회
				ArrayList<adminVO> dtos = dao.getArticleList(start, end);
				req.setAttribute("dtos", dtos);
				System.out.println("dtos" + dtos);
			}
			
			// 1 = (1 / 3) * 3 + 1
			startPage = (currentPage / pageBlock) * pageBlock + 1; // 시작 페이지
			if(currentPage % pageBlock == 0) startPage -= pageBlock; 
				System.out.println("startPage : " + startPage);
			
			// 3 = + 1 + 3 - 1
			endPage = startPage + pageBlock - 1; // 마지막 페이지
			if(endPage > pageCount) endPage = pageCount;
				System.out.println("endPage : " + endPage);
				
				req.setAttribute("cnt", cnt);			// 글갯수
				req.setAttribute("number", number);		// 글번호
				req.setAttribute("pageNum", pageNum);	// 페이지 번호
			
			if(cnt > 0) {
				req.setAttribute("startPage", startPage); // 시작 페이지
				req.setAttribute("endPage", endPage);	  // 마지막 페이지
				req.setAttribute("pageBlock", pageBlock); // 출력할 페이지 갯수
				req.setAttribute("pageCount", pageCount); //페이지 갯수
				req.setAttribute("currentPage" , currentPage); //현재 페이지
		}
	}
	// 관리자 재고관리 추가
	@Override
	public void adminwritePro(HttpServletRequest req, HttpServletResponse res) {
		adminVO dto = new adminVO();
		
		// 3단계
		dto.setBookno(Integer.parseInt(req.getParameter("bookno")));
		dto.setBookname(req.getParameter("bookname"));
		dto.setBookauthor(req.getParameter("bookauthor"));
		dto.setBookkind(req.getParameter("bookkind"));
		dto.setBookintrod(req.getParameter("bookintrod"));
		dto.setBookprice(Integer.parseInt(req.getParameter("bookprice")));
		dto.setBookcount(Integer.parseInt(req.getParameter("bookcount")));
		dto.setBookreg_date(new Timestamp(System.currentTimeMillis()));
		
		adminDAO dao = adminDAOImpl.getInstance();
		
		int insertCnt = dao.insertadmin(dto); //리턴타입
		System.out.println("insertCnt" + insertCnt);
		// 6단계. request나 session에 처리 결과를 저장(jsp에 전달하기 위함).
		req.setAttribute("dto", dto);
		req.setAttribute("insertCnt", insertCnt);
	}
	// 관리자 재고관리 상세페이지
	@Override
	public void admincontentFrom(HttpServletRequest req, HttpServletResponse res) {
		
		int bookno = Integer.parseInt(req.getParameter("bookno"));
		int pageNum = Integer.parseInt(req.getParameter("pageNum"));
		int number = Integer.parseInt(req.getParameter("number"));
		
		adminDAO dao = adminDAOImpl.getInstance();
		
		adminVO dto = dao.getArticle(bookno);
		// 6단계 request나 session에 처리 결과를 저장(jsp에 전달하기 위함).
		req.setAttribute("dto", dto);
		req.setAttribute("pageNum", pageNum);
		req.setAttribute("number", number);
	
		
	}
	// 재고관리 수정 상세페이지
	@Override
	public void adminmodifyView(HttpServletRequest req, HttpServletResponse res) {
		int bookno = Integer.parseInt(req.getParameter("bookno"));
		int pageNum = Integer.parseInt(req.getParameter("pageNum"));
		
		//
		adminDAO dao = adminDAOImpl.getInstance();
		
		int selectCnt = dao.modifyCheck(bookno);
		
		if(selectCnt ==1) {
			adminVO dto = dao.getArticle(bookno);
			req.setAttribute("dto", dto);
		}
		// 6단계 request나 session에 처리 결과를 저장(jsp에 전달하기 위함).
		req.setAttribute("selectCnt", selectCnt);
		req.setAttribute("bookno", bookno);
		req.setAttribute("pageNum", pageNum);
		
	}
	// 재고관리 수정 처리페이지
	@Override
	public void adminmodifyPro(HttpServletRequest req, HttpServletResponse res) {
		int bookno = Integer.parseInt(req.getParameter("bookno"));
		int pageNum = Integer.parseInt(req.getParameter("pageNum"));
	
		adminVO dto = new adminVO();
		dto.setBookno(bookno);
		dto.setBookname(req.getParameter("bookname"));
		dto.setBookauthor(req.getParameter("bookauthor"));
		dto.setBookkind(req.getParameter("bookkind"));
		dto.setBookintrod(req.getParameter("bookintrod"));
		dto.setBookprice(Integer.parseInt(req.getParameter("bookprice")));
		dto.setBookcount(Integer.parseInt(req.getParameter("bookcount")));
		
		adminDAO dao = adminDAOImpl.getInstance();
		
		int updateCnt = dao.updateadmin(dto);
		System.out.println("updateCnt : " + updateCnt);
		
		req.setAttribute("bookno", bookno);
		req.setAttribute("pageNum", pageNum);
		req.setAttribute("updateCnt", updateCnt);
	}
	// 관리자 재고 삭제 처리페이지
	@Override
	public void admindeletePro(HttpServletRequest req, HttpServletResponse res) {
		int bookno = Integer.parseInt(req.getParameter("bookno"));
		int pageNum = Integer.parseInt(req.getParameter("pageNum"));
		
		adminDAO dao = adminDAOImpl.getInstance();
		
		int selectCnt = dao.modifyCheck(bookno);
		int deleteCnt = 0;
		
		if(selectCnt != 0) {
			deleteCnt = dao.deleteadmin(bookno);
		}
		// 6단계 request나 session에 처리 결과를 저장(jsp에 전달하기 위함).
		req.setAttribute("deleteCnt", deleteCnt);
		req.setAttribute("selectCnt", selectCnt);
		req.setAttribute("pageNum", pageNum);	
			
		}
	
	//관리자 주문관리
	@Override
	public void adminOrderPro(HttpServletRequest req, HttpServletResponse res) {
		
		adminDAO dao = adminDAOImpl.getInstance();
		
		ArrayList<orderVO> dtos = dao.orderadmin();
		System.out.println("service1");
		req.setAttribute("dtos", dtos);
		System.out.println("service2");
	}
	
	//관리자 구매승인 클릭 시
	@Override
	public void buyok(HttpServletRequest req, HttpServletResponse res) {
		int o_id = Integer.parseInt(req.getParameter("o_id"));
		int buycount = Integer.parseInt(req.getParameter("buycount"));
		int bookno = Integer.parseInt(req.getParameter("bookno"));
		
		adminDAO dao = adminDAOImpl.getInstance();
		int updateCnt = dao.buyok(o_id, buycount, bookno);
		System.out.println("service" + updateCnt);
		
		req.setAttribute("updateCnt", updateCnt);
		
		
	}
	//관리자 환불목록
	@Override
	public void adminrefund(HttpServletRequest req, HttpServletResponse res) {
		// 3단계 화면으로부터 입력받은 값을 받아온다.
		// 게시판 관련
		int pageSize = 5;		//한 페이지당 출력할 책 갯수
		int pageBlock = 3; 		// 한 블럭당 페이지 갯수
		
		int refund = 0;			// 책 갯수
		int start = 0;			// 현재 페이지 시작 책번호
		int end = 0;			// 현재 페이지 마지막 책번호
		int number = 0; 		// 출력용 책번호
		String pageNum = null;	// 페이지 번호
		int currentPage = 0;	// 현재 페이지
		
		int pageCount = 0;		// 페이지 갯수
		int startPage = 0;		// 시작 페이지
		int endPage = 0;		// 마지막 페이지
		
		// 4단계 다형성 적용, 싱글톤 방식으로 dao 객체 생성
		adminDAO dao = adminDAOImpl.getInstance();
		
		// 5단계. 글갯수 구하기
		refund = dao.getArticleCnt1();
		System.out.println("refund :" + refund);
		
		// 6단계 request나 session에 처리 결과를 저장(jsp에 전달하기 위함).
			pageNum = req.getParameter("pageNum");
			
			if(pageNum == null) {
				pageNum = "1"; // 첫페이지 1페이지로 설정
			}
			
			// 글 30건 기준
			currentPage = Integer.parseInt(pageNum); // 현재 페이지 : 1
				System.out.println("currentPage" + currentPage);
			
			// 페이지 갯수 6 = (30 / 5) + (0)
			pageCount = (refund / pageSize) + (refund % pageSize > 0 ? 1 : 0); // 페이지 갯수 + 나머지있으면1
			
			// 1 = (1 - 1) * 5 + 1
			start = (currentPage - 1) * pageSize + 1; // 현재 페이지 시작번호 1
			
			// 5 = 1 + 5 - 1;
			end = start + pageSize - 1; // 현재 페이지 끝번호 5
				System.out.println("start : " + start);
				System.out.println("end : " + end);
			
			if(end > refund) end = refund;
			
			// 30 = 30 - (1 - 1) * 5
			number = refund - (currentPage - 1) * pageSize; // 출력용 글번호
			
				System.out.println("number : " + number);
				System.out.println("pageSize : " + pageSize);
			
			if(refund > 0) {
				// 게시글 목록 조회
				ArrayList<orderVO> dtos = dao.getArticleList1(start, end);
				req.setAttribute("dtos", dtos);
				System.out.println("dtos" + dtos);
			}
			
			// 1 = (1 / 3) * 3 + 1
			startPage = (currentPage / pageBlock) * pageBlock + 1; // 시작 페이지
			if(currentPage % pageBlock == 0) startPage -= pageBlock; 
				System.out.println("startPage : " + startPage);
			
			// 3 = + 1 + 3 - 1
			endPage = startPage + pageBlock - 1; // 마지막 페이지
			if(endPage > pageCount) endPage = pageCount;
				System.out.println("endPage : " + endPage);
				
				req.setAttribute("refund", refund);			// 글갯수
				req.setAttribute("number", number);		// 글번호
				req.setAttribute("pageNum", pageNum);	// 페이지 번호
			
			if(refund > 0) {
				req.setAttribute("startPage", startPage); // 시작 페이지
				req.setAttribute("endPage", endPage);	  // 마지막 페이지
				req.setAttribute("pageBlock", pageBlock); // 출력할 페이지 갯수
				req.setAttribute("pageCount", pageCount); //페이지 갯수
				req.setAttribute("currentPage" , currentPage); //현재 페이지
		}
	}
	//환불승인 오케이
	@Override
	public void refundOK(HttpServletRequest req, HttpServletResponse res) {
		int o_id = Integer.parseInt(req.getParameter("o_id"));
		int buycount = Integer.parseInt(req.getParameter("buycount"));
		int bookno = Integer.parseInt(req.getParameter("bookno"));
		
		adminDAO dao = adminDAOImpl.getInstance();
		int selectCnt = dao.refundOK(o_id, buycount, bookno);
		System.out.println("service" + selectCnt);
		
		req.setAttribute("selectCnt", selectCnt);
	}
	// 총결산내역
	@Override
	public void accountPro(HttpServletRequest req, HttpServletResponse res) {
		adminDAO dao = adminDAOImpl.getInstance();
		ArrayList<orderVO> dtos = dao.account();

		req.setAttribute("dtos", dtos);
	}
}
	
