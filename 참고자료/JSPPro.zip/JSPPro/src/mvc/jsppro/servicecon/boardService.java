package mvc.jsppro.servicecon;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface boardService {
	
	// 글목록
	public void boardList(HttpServletRequest req, HttpServletResponse res);

	// 상세페이지
	public void contentForm(HttpServletRequest req, HttpServletResponse res);

	// 글수정 상세페이지
	public void boardmodifyView(HttpServletRequest req, HttpServletResponse res);
	
	// 글수정 처리페이지
	public void boardmodifyPro(HttpServletRequest req, HttpServletResponse res);

	// 글작성/답글  처리페이지
	public void writePro(HttpServletRequest req, HttpServletResponse res);

	// 글 삭제 처리페이지
	public void boarddeletePro(HttpServletRequest req, HttpServletResponse res);

}
