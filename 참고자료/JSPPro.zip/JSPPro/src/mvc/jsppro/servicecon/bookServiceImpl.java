package mvc.jsppro.servicecon;


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.jsppro.persistence.bookDAO;
import mvc.jsppro.persistence.bookDAOImpl;
import mvc.jsppro.vo.bookVO;
import mvc.jsppro.vo.orderVO;

public class bookServiceImpl implements bookService {
	
	//중복확인
	@Override
	public void confirmID(HttpServletRequest req, HttpServletResponse res) {
		String strId = req.getParameter("id");
		
		// 4단계. 다형성 적용, 싱글톤 방식으로 dao 객체 생성
		bookDAO dao = bookDAOImpl.getInstance();
		
		// 5단계. 중복된 id가 있는지 확인
		int selectCnt = dao.idCheck(strId);
		// 6단계 request.session에 처리 결과를 저장(jsp에 전달하기 위함)
		req.setAttribute("selectCnt", selectCnt);
		req.setAttribute("id", strId);
	}
	// 회원가입
	@Override
	public void membershipPro(HttpServletRequest req, HttpServletResponse res) {
		
		// vo라는 바구니 생성
		bookVO vo =  new bookVO();	
		
		// 3단계. 화면으로부터 입력받은 값을 VO 바구니에 담는다.
		vo.setId(req.getParameter("id"));
		vo.setPwd(req.getParameter("pwd"));
		vo.setName(req.getParameter("name"));
		
		// email
		String email = "";
		String email1 = req.getParameter("email1");
		String email2 = req.getParameter("email2");
		
		email = email1 + "@" + email2; 
		vo.setEmail(email);
		
		// 4단계. 다형성 적용, 싱글톤 방식으로 dao 객체 생성
		bookDAO dao = bookDAOImpl.getInstance();
		
		// 5단계. vo 바구니를 DAO 파라미터에 넘겨서 insert 수행
		int insertCnt = dao.insertbook(vo);
		
		// 6단계. request나 session에 처리 결과를 저장(jsp에 전달하기 위함)
		req.setAttribute("insertCnt",insertCnt);
	}
	//로그인 처리
	@Override
	public void loginPro(HttpServletRequest req, HttpServletResponse res) {
		// 3단계. 화면으로부터 아이디, 패스워드 받아온다.
		String strId = req.getParameter("id");
		System.out.println("strId?" + strId);
		String strPwd = req.getParameter("pwd");
		System.out.println("strpwd?" + strPwd);
		// 4단계. dao 객체생성(다형성 적용, 싱글톤 방식)
		bookDAO dao = bookDAOImpl.getInstance();

		// 5단계. 모델을 사용하여 요청한 기능을 수행한다.
		int selectCnt = dao.idPwdcheck(strId, strPwd);
		
		// 6단계. request나 session에 처리 결과를 저장(jsp에 전달하기 위하
		// 로그인 성공(selectCnt == 1) 하면 세션id, cnt 1값을 넘긴다
		// 로그인 실패(비밀번호 불일치 cnt -1, 아이디가 존재하지 않을 때 cnt는 0)
		if(selectCnt == 1) {
			
			//memId 대소문자 구분
			req.getSession().setAttribute("memId", strId);
			System.out.println(req.getSession().getAttribute("memId"));
		}
		
		req.setAttribute("cnt", selectCnt);
	}
	//회원탈퇴 처리
	@Override
	public void deletePro(HttpServletRequest req, HttpServletResponse res) {
		// 3단계. 세션으로부터 아이디를, 화면으로부터 패스워드를 받아온다.	
		String strId = (String)req.getSession().getAttribute("memId");
		String strPwd = req.getParameter("pwd");
		// 4단계. dao 객체 생성(다형성 적용, 싱글톤 방식)
		bookDAO dao = bookDAOImpl.getInstance();
		// 5단계. 모델을 사용하여 요청한 기능을 수행한다.
		/*
		 * 아이디와 패스워드가 일치하면(selectCnt == 1) 입력한 회원정보를 읽어온다.
		 * 아이디와 패스워드가 일치하지 않으면  (selectCnt == -1) | 아이디가 존재하지 않으면 (selectCnt ==0)
		 */
		// 5-1. idPwdCheck();
		int selectCnt = dao.idPwdcheck(strId, strPwd);
		System.out.println("selectCnt" + selectCnt);
		// 5-2. 아이디와 패스워드가 일치하면 회원탈퇴
		int deleteCnt = 0;
		if(selectCnt == 1) {
			
			deleteCnt = dao.deleteMember(strId);
		}
		// 6단계 request나 session에 처리 결과를 저장한다(jsp에 전달하기 위함)
		req.setAttribute("selectCnt", selectCnt);
		req.setAttribute("deleteCnt", deleteCnt);
	}
	
	// 회원정보 수정 상세페이지
	@Override
	public void modifyView(HttpServletRequest req, HttpServletResponse res) {
		// 3단계. 세션으로부터 Id를, 화면으로부터 패스워드를 받아온다.
		String strId = (String)req.getSession().getAttribute("memId");
		String strPwd = req.getParameter("pwd");
		// 4단계. dao 객체 생성(다형성 적용, 싱글톤 방식)
		bookDAO dao = bookDAOImpl.getInstance();
		// 5단계. 모델을 사용하여 요청한 기능을 수행한다.
		/*
		 * 아이디와 패스워드가 일치하면(selectCnt == 1) 입력한 회원정보를 읽어온다.
		 * 아이디와 패스워드가 일치하지 않으면  (selectCnt == -1) | 아이디가 존재하지 않으면 (selectCnt ==0)
		 */
		// 5-1. idPwdCheck();
		int selectCnt = dao.idPwdcheck(strId, strPwd);
		System.out.println("selectCnt" + selectCnt);
		
		bookVO vo = null;
		
		if(selectCnt == 1) {
		// 5-2. 아이디와 패스워드가 일치하면 회원수정을 위한 회원정보를 읽어온다.
		vo = dao.getMemberInfo(strId);
		}
		
		// 6단계. request나 session에 처리 결과를 저장하면 jsp에 전달한다
		req.setAttribute("selectCnt", selectCnt);
		req.setAttribute("vo", vo);
	}
	// 회원정보 수정 처리
	@Override
	public void modifyPro(HttpServletRequest req, HttpServletResponse res) {
		
		// vo 바구니 생성
		bookVO vo = new bookVO();
		
		// 3단계. 화면으로부터 입력받은 값을 VO 바구니에 담는다.
		vo.setId((String)req.getSession().getAttribute("memId"));
		vo.setPwd(req.getParameter("pwd"));
		/*vo.setName(name);*/
		
		//email
		String email = "";
		String email1 = req.getParameter("email1");
		String email2 = req.getParameter("email2");
		
		email = email1 + "@" + email2;
		vo.setEmail(email);
		
		// 4단계. 다형성 적용, 싱글톤방식으로 객체 생성
		bookDAO dao = bookDAOImpl.getInstance();
		
		// 5단계. 모델을 사용하여 요청한 기능을 수행한다.
		// 5단계. DAO에서 vo 바구니를 dao 파라미터로 넘겨서 해당 SQL문 실행
		int updateCnt = dao.updateMember(vo);
		// 6단계. request나 session에 처리 결과를 저장하면 jsp에 전달한다
		req.setAttribute("updateCnt", updateCnt);
	}
	
	@Override
	public void booklist(HttpServletRequest req, HttpServletResponse res) {
		// 3단계 화면으로부터 입력받은 값을 받아온다.
		// 게시판 관련
		int pageSize = 5;		//한 페이지당 출력할 글 갯수
		int pageBlock = 3; 		// 한 블럭당 페이지 갯수
		
		int cnt = 0;			// 글 갯수
		int start = 0;			// 현재 페이지 시작 글번호
		int end = 0;			// 현재 페이지 마지막 글번호
		int number = 0; 		// 출력용 글번호
		String pageNum = null;	// 페이지 번호
		int currentPage = 0;	// 현재 페이지
		
		int pageCount = 0;		// 페이지 갯수
		int startPage = 0;		// 시작 페이지
		int endPage = 0;		// 마지막 페이지
		
		// 4단계 다형성 적용, 싱글톤 방식으로 dao 객체 생성
		bookDAO dao = bookDAOImpl.getInstance();
		
		
		// 6단계 request나 session에 처리 결과를 저장(jsp에 전달하기 위함).
		pageNum = req.getParameter("pageNum");
		
		if(pageNum == null) {
			pageNum = "1"; // 첫페이지 1페이지로 설정
		}
		
		// 글 30건 기준
		currentPage = Integer.parseInt(pageNum); // 현재 페이지 : 1
			System.out.println("currentPage" + currentPage);
		
		// 페이지 갯수 6 = (30 / 5) + (0)
		pageCount = (cnt / pageSize) + (cnt % pageSize > 0 ? 1 : 0); // 페이지 갯수 + 나머지있으면1
		
		// 1 = (1 - 1) * 5 + 1
		start = (currentPage - 1) * pageSize + 1; // 현재 페이지 시작번호 1
		
		// 5 = 1 + 5 - 1;
		end = start + pageSize - 1; // 현재 페이지 끝번호 5
			System.out.println("start : " + start);
			System.out.println("end : " + end);
		
		if(end > cnt) end = cnt;
		
		// 30 = 30 - (1 - 1) * 5
		number = cnt - (currentPage - 1) * pageSize; // 출력용 글번호
		
			System.out.println("number : " + number);
			System.out.println("pageSize : " + pageSize);
		
			// 게시글 목록 조회
			ArrayList<bookVO> dtos = dao.getbookList(start,end);
			req.setAttribute("dtos" ,dtos); //큰바구니 : 게시글목록을 넘겼다 cf)작은 바구니 : 게시글 1건
	
		
		// 1 = (1 / 3) * 3 + 1
		startPage = (currentPage / pageBlock) * pageBlock + 1; // 시작 페이지
		if(currentPage % pageBlock == 0) startPage -= pageBlock; 
			System.out.println("startPage : " + startPage);
		
		// 3 = + 1 + 3 - 1
		endPage = startPage + pageBlock - 1; // 마지막 페이지
		if(endPage > pageCount) endPage = pageCount;
			System.out.println("endPage : " + endPage);
			
			req.setAttribute("cnt", cnt);			// 글갯수
			req.setAttribute("number", number);		// 글번호
			req.setAttribute("pageNum", pageNum);	// 페이지 번호
		
		if(cnt > 0) {
			req.setAttribute("startPage", startPage); // 시작 페이지
			req.setAttribute("endPage", endPage);	  // 마지막 페이지
			req.setAttribute("pageBlock", pageBlock); // 출력할 페이지 갯수
			req.setAttribute("pageCount", pageCount); //페이지 갯수
			req.setAttribute("currentPage" , currentPage); //현재 페이지
		}
		
		
		
	}
	// 장바구니 리스트로 뿌리기
	@Override
	public void cartlist(HttpServletRequest req, HttpServletResponse res) {
		// 3단계 화면으로부터 입력받은 값을 받아온다.
			// 게시판 관련
			int pageSize = 5;		//한 페이지당 출력할 글 갯수
			int pageBlock = 3; 		// 한 블럭당 페이지 갯수
			
			int cnt = 0;			// 글 갯수
			int start = 0;			// 현재 페이지 시작 글번호
			int end = 0;			// 현재 페이지 마지막 글번호
			int number = 0; 		// 출력용 글번호
			String pageNum = null;	// 페이지 번호
			int currentPage = 0;	// 현재 페이지
			
			int pageCount = 0;		// 페이지 갯수
			int startPage = 0;		// 시작 페이지
			int endPage = 0;		// 마지막 페이지
			
			// 4단계 다형성 적용, 싱글톤 방식으로 dao 객체 생성
			bookDAO dao = bookDAOImpl.getInstance();
			
			// 6단계 request나 session에 처리 결과를 저장(jsp에 전달하기 위함).
			pageNum = req.getParameter("pageNum");
			
			if(pageNum == null) {
				pageNum = "1"; // 첫페이지 1페이지로 설정
			}
			
			// 글 30건 기준
			currentPage = Integer.parseInt(pageNum); // 현재 페이지 : 1
			System.out.println("currentPage" + currentPage);
			
			// 페이지 갯수 6 = (30 / 5) + (0)
			pageCount = (cnt / pageSize) + (cnt % pageSize > 0 ? 1 : 0); // 페이지 갯수 + 나머지있으면1
			
			// 1 = (1 - 1) * 5 + 1
			start = (currentPage - 1) * pageSize + 1; // 현재 페이지 시작번호 1
			
			// 5 = 1 + 5 - 1;
			end = start + pageSize - 1; // 현재 페이지 끝번호 5
				System.out.println("start : " + start);
				System.out.println("end : " + end);
			
			if(end > cnt) end = cnt;
			
			// 30 = 30 - (1 - 1) * 5
			number = cnt - (currentPage - 1) * pageSize; // 출력용 글번호
			
			System.out.println("number : " + number);
			System.out.println("pageSize : " + pageSize);
			
			//장바구니 목록 가져오기
			ArrayList<orderVO> dtos = dao.getcartList(start,end);
			req.setAttribute("dtos" ,dtos); //큰바구니 : 게시글목록을 넘겼다 cf)작은 바구니 : 게시글 1건
		
			
			// 1 = (1 / 3) * 3 + 1
			startPage = (currentPage / pageBlock) * pageBlock + 1; // 시작 페이지
			if(currentPage % pageBlock == 0) startPage -= pageBlock; 
				System.out.println("startPage : " + startPage);
			
			// 3 = + 1 + 3 - 1
			endPage = startPage + pageBlock - 1; // 마지막 페이지
			if(endPage > pageCount) endPage = pageCount;
				System.out.println("endPage : " + endPage);
				
				req.setAttribute("cnt", cnt);			// 글갯수
				req.setAttribute("number", number);		// 글번호
				req.setAttribute("pageNum", pageNum);	// 페이지 번호
			
			if(cnt > 0) {
				req.setAttribute("startPage", startPage); // 시작 페이지
				req.setAttribute("endPage", endPage);	  // 마지막 페이지
				req.setAttribute("pageBlock", pageBlock); // 출력할 페이지 갯수
				req.setAttribute("pageCount", pageCount); //페이지 갯수
				req.setAttribute("currentPage" , currentPage); //현재 페이지
			}
}
	// 장바구니 추가
	@Override
	public void cartPro(HttpServletRequest req, HttpServletResponse res) {
		orderVO dto = new orderVO();
		
	
		int bookno = (Integer.parseInt(req.getParameter("bookno")));
		String id = (String)req.getSession().getAttribute("memId");
		String buycount = req.getParameter("buycount");
		System.out.println("장바구니 인설트시 아이디?"+id);
		
		bookDAO dao = bookDAOImpl.getInstance();
		
		int insertOrder = dao.insertOrder(id,bookno,buycount );
		
		req.setAttribute("dto", dto);
		req.setAttribute("insertOrder", insertOrder);
	}
	// 장바구니 삭제
	@Override
	public void cartdelete(HttpServletRequest req, HttpServletResponse res) {
		int o_id= Integer.parseInt(req.getParameter("o_id"));
		
		bookDAO dao = bookDAOImpl.getInstance();
		
		int deleteCnt = dao.deletecart(o_id);
		
		req.setAttribute("deleteCnt", deleteCnt);
	}
	//장바구니 구매
		@Override
		public void cartbuy(HttpServletRequest req, HttpServletResponse res) {
			
			int o_id = Integer.parseInt(req.getParameter("o_id"));
			int bookno = Integer.parseInt(req.getParameter("bookno"));
			String buycount = req.getParameter("buycount");
			String memId =(String) req.getSession().getAttribute("memId");
			
			System.out.println(buycount);
			System.out.println("o_id : " + o_id);
			
			bookDAO dao = bookDAOImpl.getInstance();
			orderVO dto= new orderVO();
			
			dto.setO_id(o_id);
			dto.setBookno(bookno);
			dto.setBuycount(buycount);
			dto.setM_id((String)req.getSession().getAttribute("memId"));
			
			int updatecnt = dao.cartbuyPro(dto);
			System.out.println("updatecnt?"+updatecnt);
			if (updatecnt > 0) {
			
				// 게시글 목록 조회
				ArrayList<orderVO> dtos = dao.orderList(memId);	

				// jsp로 게시글 목록(= 큰 바구니) 넘긴다.
				req.setAttribute("dtos", dtos);
			}
			
			req.setAttribute("updatecnt", updatecnt);
		}
		//구매목록
		@Override
		public void orderList(HttpServletRequest req, HttpServletResponse res) {
			String memId =(String) req.getSession().getAttribute("memId");

			bookDAO dao = bookDAOImpl.getInstance();
			orderVO dto= new orderVO();

			dto.setM_id((String)req.getSession().getAttribute("memId"));

			ArrayList<orderVO> dtos = dao.orderList(memId);	
			
			req.setAttribute("dtos", dtos);

		}
		//고객 환불 요청
		@Override
		public void refund(HttpServletRequest req, HttpServletResponse res) {
			int o_id = Integer.parseInt(req.getParameter("o_id"));	
			
			bookDAO dao = bookDAOImpl.getInstance();
			int updateCnt = dao.refund(o_id);
			
			req.setAttribute("updateCnt", updateCnt);
			
		}
	}

