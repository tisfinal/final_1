package mvc.jsppro.customcon;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.jsppro.servicecon.boardServiceImpl;
import mvc.jsppro.servicecon.bookServiceImpl;

@WebServlet("*.cu")
public class cuController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public cuController() {
        super();
    }

 // 1단계 : HTTP 요청받음
 	protected void doGet(HttpServletRequest req, HttpServletResponse res) 
 			throws ServletException, IOException {
 				ActionDo(req, res);
 	}
 	
 	protected void doPost(HttpServletRequest req, HttpServletResponse res)
 			throws ServletException, IOException {
 				ActionDo(req, res);
 	}
 	// 2단계 : 요청 분석		
 	public void ActionDo(HttpServletRequest req, HttpServletResponse res)
 			throws ServletException, IOException {
 		
 		// 한글 안깨지게 처리(안하면 DB에 한글이 깨져서 Insert)
 		req.setCharacterEncoding("UTF-8");
 		
 		String viewPage = null;
		String uri = req.getRequestURI();
		String contextPath = req.getContextPath();	// 프로젝트명
		String url = uri.substring(contextPath.length());
 	
		//2단계. 요청분석
		//첫 메인페이지
	 	if(url.equals("/main.cu") || url.equals("/*.cu")) {
	 		System.out.println("/main.cu");
	 		
	 		viewPage = "/viewpage/main.jsp";
	 
	 	// 회원가입 폼페이지
	 	}else if(url.equals("/membershipForm.cu")) {
	 		System.out.println("/membershipForm.cu");
	 		
	 		viewPage = "/viewpage/membershipForm.jsp";
	 	
	 	// 중복처리 페이지
	 	}else if(url.equals("/confirmID.cu")) {
	 		System.out.println("/confirmID.cu");
	 	
	 		bookServiceImpl service = new bookServiceImpl();
	 		service.confirmID(req, res);
	 		
	 		viewPage = "/viewpage/confirmID.jsp";
	 		
	 	// 회원가입처리 페이지
	 	}else if(url.equals("/membershipPro.cu")){
	 		System.out.println("/membershipPro.cu");
	 		
	 		bookServiceImpl service = new bookServiceImpl(); 
			 // service는 우리 학원 예제 기준 MemberDAO 이다. 
	 		service.membershipPro(req, res); 
			 // dao.insertMember();
	 		
	 		viewPage = "/viewpage/loginPro.jsp";
		// 회원가입 성공 :
		} else if(url.equals("/mainSuccess.cu")) {
			System.out.println("/mainSuccess.cu");
			
			int cnt = Integer.parseInt(req.getParameter("insertCnt"));
			req.setAttribute("cnt", cnt);
			
			viewPage = "/viewpage/main.jsp";
		
		// 로그인
		}else if (url.equals("/loginPro.cu")){
			System.out.println("loginPro.cu");
			
			req.getSession().getAttribute("memId");
			
			bookServiceImpl service = new bookServiceImpl();
			service.loginPro(req, res);
	 		viewPage = "/viewpage/loginPro.jsp";
		// 로그인후
		}else if (url.equals("/loginPro.cu")) {
			System.out.println("/main.cu");
			req.getSession().getAttribute("memId");
	 		viewPage = "/viewpage/loginPro.jsp";
		
	 	// 로그아웃
		}else if(url.equals("/logout.cu")) {
			System.out.println("/logout.cu");
			
			//3. 세션 삭제 방법 3가지
			// request.getSession().setAttribute("key", null);
			// request.getSession().removeAttribute("key");
			// request.getSession().invalidate();
			
			req.getSession().removeAttribute("memId");
			
			viewPage = "/viewpage/main.jsp";
		
		// 회원탈퇴
		}else if(url.equals("/deleteForm.cu")) {
			System.out.println("/deleteForm.do");
			
			viewPage = "/viewpage/deleteForm.jsp";
		
		// 회원탈퇴 처리페이지
		}else if(url.equals("/deletePro.cu")) {
			System.out.println("/deletePro.cu");
			
			bookServiceImpl service = new bookServiceImpl();
			service.deletePro(req, res);
			
			viewPage = "/viewpage/deletePro.jsp";
		
		// 회원정보 수정
		} else if(url.equals("/modifyForm.cu")) {
			System.out.println("/modifyForm.cu");
			
			viewPage = "/viewpage/modifyForm.jsp";
		
		// 회원정보 상세페이지
		} else if(url.equals("/modifyView.cu")) {
			System.out.println("/modifyView.cu");
			
			bookServiceImpl service = new bookServiceImpl();
			service.modifyView(req, res);
			
			viewPage = "/viewpage/modifyView.jsp";
		
		// 회원정보 수정처리
		} else if(url.equals("/modifyPro.cu")) {
			System.out.println("/modifyPro.cu");
			
			bookServiceImpl service = new bookServiceImpl();
			service.modifyPro(req, res);
			
			viewPage = "/viewpage/modifyPro.jsp";
	
		}//2단계: 요청 분석
	 	// 글 목록
		else if(url.equals("/boardList.cu")){
	 		System.out.println("/boardList.cu");
	 		
	 		boardServiceImpl service = new boardServiceImpl();
	 		service.boardList(req, res);
	 		
	 		viewPage = "/board/boardList.jsp";
	 	}
	 	// 상세페이지
		else if(url.equals("/contentForm.cu")) {
			System.out.println("/contentForm.cu");
			
			boardServiceImpl service = new boardServiceImpl();
	 		service.contentForm(req, res);
	 		
	 		viewPage = "/board/contentForm.jsp";
		}
	 	// 수정페이지
		else if(url.equals("/boardmodifyForm.cu")) {
			System.out.println("/boardmodifyForm.cu");
			
			int num = Integer.parseInt(req.getParameter("num"));
			int pageNum = Integer.parseInt(req.getParameter("pageNum"));
			
			req.setAttribute("num", num);
			req.setAttribute("pageNum", pageNum);

			viewPage="/board/boardmodifyForm.jsp";
		}
	 	
	 	//글 수정 상세페이지
	 	
		else if(url.equals("/boardmodifyView.cu")) {
			System.out.println("boardmodifyView.cu");
			
			boardServiceImpl service = new boardServiceImpl();
			service.boardmodifyView(req, res);
			
			viewPage = "/board/boardmodifyView.jsp";
		
		//글 수정 처리페이지
		}else if(url.equals("/boardmodifyPro.cu")) {
			System.out.println("/boardmodifyPro.cu");
			
			boardServiceImpl service = new boardServiceImpl();
			service.boardmodifyPro(req, res);
			
			viewPage = "/board/boardmodifyPro.jsp";
			
		// 글쓰기 폼페이지
		}else if(url.equals("/writeForm.cu")){
			System.out.println("/writeForm.cu");
			
			// 제목글(답변글이 아닌 경우)
			int num = 0;
			int ref = 1;		// 그룹화 아이디
			int ref_step = 0;	// 글 순서(행)
			int ref_level = 0;	// 글레벨(들여쓰기)
			int pageNum = 0;

			

			// 답변글
			// contentForm.jsp에서 get방식으로 넘긴 값 num, ref, ref_step, ref_level을 받는다.
			if(req.getParameter("num") != null) {
				num = Integer.parseInt(req.getParameter("num"));
				ref = Integer.parseInt(req.getParameter("ref"));
				ref_step = Integer.parseInt(req.getParameter("ref_step"));
				ref_level = Integer.parseInt(req.getParameter("ref_level"));
				pageNum = Integer.parseInt(req.getParameter("pageNum"));

			}
			// 답글 
			req.setAttribute("num", num);
			req.setAttribute("ref", ref);
			req.setAttribute("ref_step", ref_step);
			req.setAttribute("ref_level", ref_level);
			req.setAttribute("pageNum", pageNum);

			viewPage = "/board/writeForm.jsp";
		
		//글작성 처리
		}else if(url.equals("/writePro.cu")) {
			System.out.println("/writePro.cu");
			
			boardServiceImpl service = new boardServiceImpl();
			service.writePro(req, res);
			
			viewPage="/board/writePro.jsp";
		
		// 글 삭제
		}else if(url.equals("/boarddeleteForm.cu")){
			System.out.println("/boarddeleteForm.cu");
			
			int num = Integer.parseInt(req.getParameter("num"));
			int pageNum = Integer.parseInt(req.getParameter("pageNum"));
			
			req.setAttribute("num", num);
			req.setAttribute("pageNum", num);
			
			viewPage = "/board/boarddeleteForm.jsp";
		
		// 글 삭제처리
		}else if(url.equals("/boarddeletePro.cu")) {
			System.out.println("/boarddeletePro.cu");
			
			boardServiceImpl service = new boardServiceImpl();
			service.boarddeletePro(req, res);
			
			viewPage ="/board/boarddeletePro.jsp";
		
		//3단계
		// 고객 장바구니 목록
		}else if(url.equals("/cartForm.cu")) {
			System.out.println("/cartForm.cu");
			 
			bookServiceImpl service = new bookServiceImpl();
			service.cartlist(req, res);
			
			viewPage ="/cart/cartForm.jsp";
		//책목록
		}else if(url.equals("/booklist.cu")) {
			System.out.println("/booklist.cu");
			
			bookServiceImpl service = new bookServiceImpl();
			service.booklist(req, res);
			
			viewPage ="/viewpage/sihome.jsp";
		
		//책 장바구니 보내기
		}else if(url.equals("/cartPro.cu")) {
			System.out.println("/cartPro.cu");
			
			bookServiceImpl service = new bookServiceImpl();
			service.cartPro(req, res);
			
			viewPage = "viewpage/cartPro.jsp";
		//장바구니 목록 삭제
		}else if(url.equals("/cartdeleteForm.cu")) {
			System.out.println("/cartdeleteForm.cu");
			
			int o_id= Integer.parseInt(req.getParameter("o_id"));
			
			bookServiceImpl service = new bookServiceImpl();
			service.cartdelete(req, res);
			
			viewPage = "cart/cartdeleteForm.jsp";
		
		// 구매시작
		}else if(url.equals("/cartbuy.cu")) {
			System.out.println("/cartbuy.cu");
			
			req.setAttribute("status", 2);
			bookServiceImpl service = new bookServiceImpl();		
			service.cartbuy(req, res);
		
			viewPage = "/cart/orderListForm.jsp";
		
		// 구매목록
		}else if(url.equals("/orderList.cu")) {
			System.out.println("/orderList.cu");
			
			bookServiceImpl service = new bookServiceImpl();		
			service.orderList(req, res);
			
			viewPage = "/cart/orderListForm.jsp";
		
		// 고객 환불요청
		}else if(url.equals("/refund.cu")) {
			System.out.println("/refund.cu");
			
			bookServiceImpl service = new bookServiceImpl();
			service.refund(req,res);
			
			viewPage = "/cart/refund.jsp";
		}
	 	
	 	RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage);
		dispatcher.forward(req, res);
 	}
 }
