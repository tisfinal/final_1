8/2 개인공부 자료 . 

이 예제는 로그인회원가입만 db 와 연동되있고  
판매하는 상품들은 db와 연동되지않고 직접 작성한 더미데이터들이다. 

책파는 사이트  db 연동은 member  그멤버가 maxim 구매했다,장바구니담았다 까지 db에 들어가고



우리 학원예제처럼 *.do 로 안하고 *.cu, *.ad 로 작성이 돼있다.


그리고 처리하는 스타일이 다르다.  어떻게 다른지 설명하기. 

src,WebContent,readMe.txt
bulid ... 는 무시하고

*src (백앤드) , *WebContent(프론트)



index.jsp  를 먼저본다 

2초뒤에 {window.location='main.cu'}  main.cu 로 보낸다고한다 (tis예제기준 main.do or main.me)

main.cu 가 어디로 보내지는건지 찾아본다   src/cutromcon/cuController.java 로 들어가본다 . 

47번줄 	if(main.cu) 일경우  => 		viewPage = "/viewpage/main.jsp"; 로  이동해 ! 

 *WebContent 에  viewpage/main.jsp 를 본다 .   main 페이지 이지만, 코드가 길지않다.  
 
 main.jsp 문서중 중요한것만 읽자면  이 4줄이다 .

4개를 include (불러온다) 한다. 

 <%@ include file="/viewpage/setting.jsp" %>
            // main 만약 우리가 부트스트랩을 쓴다거나 제이쿼리를 쓴다면 모든 페이지에 제이쿼리나 부트스트랩 jstl link 를 작성해야한다
             그래서 setting.jsp 를 따로만들어서 이곳에 link 들만 적고  이것을 include 하면 된다. 

<%@ include file="/common/header.jsp" %>
                
<%@ include file="/common/body.jsp" %> <<

<%@ include file="/common/footer.jsp" %>

나머지 3개는 viewPage/ ? 가아니라 common/ ? 이다   common 은 대부분의 페이지들에서 재사용 되는
 컴퍼넌트(부품) 들을 모은 곳 인거 같다. 
common => 공통으로 들어가는 애들이 모인곳. 
viewPage랑 common 랑 뭐가 다른지? 

우리팀이 커뮤니티 하는 용어 



컴퍼넌트 {  헤더: "로그인,회원가입,메인으로가기,장바구니...",  
            => 이 앱에서 검색한 상품들의 list 를 보는 페이지에서도  이 컴퍼넌트는 필요할것이다. (재사용필요하다는이야기)
         바디 : " 우리 '야놀자' 기준 메인페이지에 깔릴 모텔탑차트! 1.신라호텔 2.고려호텔 ...  요러한 데이터들이 담길 공간"
         
         푸터: 설명 생락 뭐가 써있나 보기만 하시면 됩니다. 

 }


 이렇게 main.jsp 에서 이제 우리가 이동하고 싶은 페이지로 이동 한다.   main.jsp 가 include 한 header.jsp 에 있는
 회원가입 하는걸 보자 .

 main.jsp > header.jsp 에있는 
    c:if 문을 보면 여러개인것같지만  사실 2개이다 

    if (memId != null ) , else if (memId == null )

    memId 는 세션에 등록되있는 아이디 인것같다 좀 더 읽다가 로그인 하는 부분을 봐야 memId 가 뭔지 자세히 알수있다 . 

    무튼 우린 로그인이 안된 상태이니 
     if (memId == null )  인 경우이니  로그인 과 회원가입 link 만 볼수 있다. 

     회원가입 먼저보겠다. 

    <li><a href="../JSPPro/membershipForm.cu" alt="">회원가입</a></li> 

    회원가입을 링크를 클릭했다는 가정 으로 JSPPro/membershipForm.cu 로 이동해본다 

    membershipForm.cu는  src/customcon/cuController.java 에 있다 . 

    53번줄 viewPage = "/viewpage/membershipForm.jsp";   저기로 이동해보자 ! 

    중요하게 읽을 거는  <jsp:include page="../common/bodymember.jsp" /> 이다 . 

    아까 main 에서 body 대신 page="../common/bodymember.jsp를 인클루드 했다 . 


    나머지는 세팅,헤더,푸터 인클루드한 내용, 그리고 이 곳은 회원가입 하는 폼 이있는 페이지 이니 유효성체크하는 스크립트와 style 
    정도가 있다고 생각하면 될것같다.  

    ../common/bodymember.jsp 를 봐보자 

    우리가 알수있는건  회원가입할 id,pw 등등 을 적고 적은 것 들을  membershipPro.cu 로 보내는 form 이 있구나! 

    라고만 보면 된다.   그럼  membershipPro.cu 를 src/ 여기서 찾아보장 


    ==>> 이렇게 흐름 읽어보시면 됩니다  천천히 읽어도 한시간도 안걸리기때문에 한번 보시면 도움 될껍니다. 








