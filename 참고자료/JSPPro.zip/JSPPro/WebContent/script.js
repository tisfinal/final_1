/**
 JSPPro* 
 */
var msg_id = "아이디를 입력해주세요.!!";
var msg_idpwdchk = "아이디 패스워드를 다시 확인해주세요.";
var msg_pwd = "비밀번호를 입력해주세요.!!";
var msg_repwd = " 비밀번호를 재입력하세요.!";
var msg_pwdChk = "비밀번호가 다릅니다!!";
var msg_name = "이름을 입력하세요!";
var msg_birth = "주민번호를 입력하세요!";
var msg_email = "이메일 입력하세요!";
var msg_emailChk = "이메일 형식에 일치하지 않습니다!";
var msg_confirmId = "중복확인을 해주세요!!";

var insertError = "회원가입에 실패했습니다.\n확인 후 다시 시도하세요.!!";
var updateError = "회원정보 수정에 실패했습니다.\n확인 후 다시 시도하세요.!!";
var deleteError = "회원탈퇴에 실패했습니다.\n확인 후 다시 시도하세요.!!";
var passwdError = "입력하신 비밀번호가 일치하지 않습니다.\n확인 후 다시 시도하세요.!!";

// 에러메시지
function errorAlert(errorMsg) {
	alert(errorMsg);
	window.history.back();// 이전 페이지로 이동
}

// 메인페이지
function mainFocus() {
	document.mainform.id.focus();
}

// 메인화면에서 버튼 클릭시 메세지 출력
function mainCheck() {
	if (!document.mainform.id.value) {
		alert(msg_id);
		document.mainform.id.focus();
		return false;
	} else if (!document.mainform.pwd.value) {
		alert(msg_pwd);
		document.mainform.pwd.focus();
		return false;
	}
}
// 회원가입 페이지
function inputFocus() {
	document.membershipform.id.focus();
}

// 회원가입 버튼 클릭시
function inputCheck() {
	if (!document.membershipform.id.value) { //아이디
		alert(msg_id);
		document.membershipform.id.focus();
		return false;

	} else if (!document.membershipform.pwd.value) { //비번
		alert(msg_pwd);
		document.membershipform.pwd.focus();
		return false;

	} else if (!document.membershipform.repwd.value) { //비번확인
		alert(msg_repwd);
		document.membershipform.repwd.focus();
		return false;

	} else if (document.membershipform.pwd.value != document.inputform.repwd.value) { //비번 != 비번확인
		alert(msg_pwdChk);
		document.membershipform.repwd.focus();
		return false;

	} else if (!document.membershipform.name.value) { //이름
		alert(msg_name);
		document.membershipform.name.focus();
		return false;

	} else if (!document.membershipform.email1.value) {	//이메일
		alert(msg_email);
		document.membershipform.email1.focus();
		return false;

		// 이메일2값 null && 직접입력
	} else if (!document.membershipform.email2.value
			&& document.membershipform.email3.value == 0) { //이메일
		alert(msg_emailChk);
		document.membershipform.email2.focus();
		return false;

		// 중복확인 버튼을 클릭하지 않는 경우
		// hiddenId : 중복확인 버튼 클릭 여부 체크(0:클릭안함, 1:클릭함)
		// 체크전체 조건 : inputform.jsp의 form안 맨위에<input type="hidden"
		// name="hiddenId" value="0"> 추가
	} else if (document.membershipform.hiddenId.value == 0) {
		alert(msg_confirmId);
		document.membershipform.dupChk.focus();
		return false;
	}
}

function selectEmailChk() {
	// 직접입력
	if (document.membershipform.email3.value == 0) {
		document.membershipform.email2.value = "";
		document.membershipform.email2.focus();

		// 이메일 직접입력이 아닌경우 select box의 값(email3)을 email2의 값으로 설정
	} else {
		document.membershipform.email2.value = document.membershipform.email3.value;
	}
}

// 중복확인 버튼 클릭시 서브창 open
function confirmID() {
	// id값 미입력시
	if (!document.membershipform.id.value) {
		alert(msg_id);
		document.membershipform.id.focus();
		return false;
	}
	/*
	 * window.open("파일명", "윈도우명", "창속성"); url="주소?속성=" +속성값; --> get방식
	 */
	var url = "confirmID.cu?id=" + document.membershipform.id.value;
	window.open(url, "confirm", "menubar=no, width=300, height=200");
}

// 중복확인 버튼 클릭시 id로 포커스
function confirmIDFocus() {
	document.confirmform.id.focus();
}

// 중복 확인 차에서 id입력 여부
function confirmIDCheck() {
	if (!document.confirmform.id.value) {
		alert(msg_id);
		document.confirmform.id.focus();
		return false;
	}
}

// opener : window 객체의 open() 메고드로 열린 새창(=중복확인창)에서, 열어준 부모창(=회원가입창)에 저블할 때 사용
// self.close(); 메시지없이 현재창을 닫을때 사용
// hiddenId : 중복확인 버튼 클릭 여부 체크(0:클릭 안함, 1:클릭함)
function setId(id) {
	opener.document.membershipform.id.value = id;
	opener.document.membershipform.hiddenId.value = "1";
	self.close();
}

// 회원탈퇴, 회원정보 수정 
function passwdFocus() {
	document.passwdform.pwd.focus();
}

function passwdCheck() {
	if (!document.passwdform.pwd.value) {
		alert(msg_pwd);
		document.passwdform.pwd.focus();
		return false;
	}
	
// 회원정보 수정
function modifyFocus() {
		document.modifyform.pwd.focus();
	}
}
// 회원정보 수정
function modifyView() {
	// 직접입력
	if (document.modifyform.email3.value == 0) {
		document.modifyform.email2.value = "";
		document.modifyform.email2.focus();

		// 이메일 직접입력이 아닌경우 select box의 값(email3)을 email2의 값으로 설정
	} else {
		document.modifyform.email2.value = document.modifyform.email3.value;
	}
}

function modifyCheck(){
	//비밀번호 입력값이 없을 때
	if(!document.modifyform.pwd.value){
		alert(msg_pwd);
		document.modifyform.pwd.focus();
		return false;
	}
	//비밀번호 확인값이 없을 때
	else if(!document.modifyform.repwd.value) {
		alert(msg_repwd);
		document.modifyform.repwd.focus();
		return false;
	}
	//비밀번호 불일칠시
	else if(document.modifyform.pwd.value != document.modifyform.repwd.value) {
		alert(msg_pwd);
		document.modifyform.pwd.focus();
		return false;
	}
	
	//이메일 입력값이 없을 때
	else if(!document.modifyform.email1.value){
		alert(msg_email);
		document.modifyform.email1.focus();
		return false;
	}
	else if(!document.modifyform.email2.value &&
			!document.modifyform.email3.value == 0){
		alert(msg_email);
		document.modifyform.email2.focus();
		return false;
	}
}

