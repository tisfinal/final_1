<main id="main" class="form">
  <form class="form-signin bgcolor col-sm-6 center" id="join" action ="" method="POST">
    <h1 class="h3 mb-3 font-weight-normal">SIGN UP</h1>
    
    <label for="inputEmail" class="">Email address</label>
    
    <input type="email" id="1" name="email" class="form-control mb-3"   autofocus>
    <p id="invalid-1"></p>
    
    <label for="inputPassword" class="">Password</label>
    
    <input type="password" id="2" name="password1" class="form-control mb-3"  >
    <p id="invalid-2"></p>

    <label for="inputPassword" class="">Repeat Password</label>
    
    <input type="password" id="3" name="password2" class="form-control mb-3"  >
    <p id="invalid-3"></p>
    
    <label for="inputEmail" class="">First Name</label>
   
    <input type="fname" id="4" name="fname" class="form-control mb-3"  >
     <p id="invalid-4"></p>

    <label for="inputEmail" class="">Last Name</label>
    
    <input type="lname" id="5" name="lname" class="form-control mb-3"  >
    <p id="invalid-5"></p>

    <input type="checkbox" id="6" name="check" class="mb-3"  >
    
    I have read and understand the Privacy and Cookies Policy
    <p id="invalid-6"></p>
    
    <button class="btn btn-lg btn-dark btn-block mt-4" type="submit">SIGN UP</button>
  </form>
</main>
  