<footer class="footer border border-dark border-bottom-0 border-right-0 border-left-0">
    <div class="container">
        <p class="goto-top">Back to top</p>
    </div>
</footer>