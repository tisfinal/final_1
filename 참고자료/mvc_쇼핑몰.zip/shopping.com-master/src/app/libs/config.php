<?php

	define('_ROOT', $_SERVER['DOCUMENT_ROOT']);
	